

<?php $__env->startSection('title', 'Detail Pesanan'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="h3">Detail Pesanan</h1>

    <div class="card position-relative">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Detail Pesanan</h5>
        </div>

        <div class="card-body position-relative">
            
            <?php
                $status = $order->status;
                $badgeClass = match($status) {
                    'Belum Bayar' => 'badge bg-danger',
                    'Dalam Proses' => 'badge bg-warning text-dark',
                    'Selesai' => 'badge bg-success',
                    default => 'badge bg-secondary',
                };
            ?>
            <span style="position: absolute; top: 1rem; right: 1rem; font-size: 1.25rem; padding: 0.5em 1em;" class="<?php echo e($badgeClass); ?>">
                <?php echo e($status); ?>

            </span>

            <p><strong>Order ID:</strong> <?php echo e($order->order_id); ?></p>
            <p><strong>Nama Pelanggan:</strong> <?php echo e($order->customer->full_name); ?></p>
            <p><strong>Tanggal Pesanan:</strong> <?php echo e($order->order_date); ?></p>
            <p><strong>Total Harga:</strong> Rp <?php echo e(number_format($order->total_price, 2)); ?></p>

            <h5 class="mt-4">Detail Produk</h5>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nama Produk</th>
                        <th>Jumlah</th>
                        <th>Harga</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($detail->product->product_name ?? 'Produk tidak ditemukan'); ?></td>
                            <td><?php echo e($detail->quantity); ?></td>
                            <td>Rp <?php echo e(number_format($detail->price, 2)); ?></td>
                            <td>Rp <?php echo e(number_format($detail->quantity * $detail->price, 2)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <h5 class="mt-5">Mutasi Angsuran</h5>
            <?php if($order->pembayaran->count()): ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal Pembayaran</th>
                            <th>Jumlah Bayar (Rp)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $totalBayar = 0;
                        ?>
                        <?php $__currentLoopData = $order->pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $bayar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $totalBayar += $bayar->jumlah_bayar;
                            ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($bayar->tanggal_pembayaran)->format('d/m/Y')); ?></td>
                                <td>Rp <?php echo e(number_format($bayar->jumlah_bayar, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th colspan="2" class="text-end">Total Angsuran</th>
                            <th>Rp <?php echo e(number_format($totalBayar, 2)); ?></th>
                        </tr>
                        <tr>
                            <th colspan="2" class="text-end">Sisa Tagihan</th>
                            <th>Rp <?php echo e(number_format($order->sisa_tagihan, 2)); ?></th>
                        </tr>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-muted">Belum ada pembayaran untuk pesanan ini.</p>
                <p><strong>Sisa Tagihan:</strong> Rp <?php echo e(number_format($order->sisa_tagihan, 2)); ?></p>
            <?php endif; ?>

            <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-secondary mt-3">Kembali</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\percobaan5\resources\views/orders/show.blade.php ENDPATH**/ ?>