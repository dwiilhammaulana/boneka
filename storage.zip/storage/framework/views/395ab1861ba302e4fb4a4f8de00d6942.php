<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Yoga Studio Template">
    <meta name="keywords" content="Yoga, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mobil Sip</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900&display=swap"
        rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/bootstrap.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/font-awesome.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/nice-select.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/owl.carousel.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/magnific-popup.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/slicknav.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/style.css')); ?>" type="text/css">
</head>

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>
    
    <!-- Search model -->
	<div class="search-model">
		<div class="h-100 d-flex align-items-center justify-content-center">
			<div class="search-close-switch">+</div>
			<form class="search-model-form">
				<input type="text" id="search-input" placeholder="Search here.....">
			</form>
		</div>
	</div>
	<!-- Search model end -->

    <!-- Header Section Begin -->
    <header class="header-section">
        <div class="container-fluid">
            <div class="inner-header">
                <div class="logo">
                    <a href="<?php echo e(route('public.home')); ?>">
                        <img src="<?php echo e(asset('img/Logo.png')); ?>" alt="Logo ASSTORE" class="logo-img">
                    </a>
                </div>
                <div class="header-right">
                    <!-- Menampilkan icon profile untuk pengguna yang sudah login -->
                    <?php if(auth()->guard('customer')->check()): ?>
                        <a href="<?php echo e(route('public.cart')); ?>">
                            <img src="<?php echo e(asset('ecomerce/img/icons/bag.png')); ?>" alt="">
                            <span><?php echo e(session('cart') ? array_sum(array_column(session('cart'), 'quantity')) : 0); ?></span> <!-- Menampilkan jumlah barang di cart -->
                        </a>
                    <?php endif; ?>

                    <!-- Menampilkan keranjang belanja untuk pengguna yang sudah login -->
                    <?php if(auth()->guard()->guest()): ?>
                        <a href="<?php echo e(route('login')); ?>">
                            <img src="<?php echo e(asset('ecomerce/img/icons/user.png')); ?>" alt=""> <!-- Icon untuk login -->
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Menu Navigasi -->
                <nav class="main-menu mobile-menu" style="center">
                    <ul>
                        <li><a class="active" href="<?php echo e(route('public.home')); ?>">Home</a></li>
                        <li><a href="<?php echo e(route('public.shop')); ?>">Shop</a></li>
                        <li><a href="<?php echo e(route('public.contact')); ?>">Contact</a></li>
                        
                        <?php if(Auth::guard('customer')->check()): ?>
                            
                            <li><span>Profile</span>
                                <ul class="sub-menu">
                                    <li><a href="<?php echo e(route('customer.profile')); ?>"><?php echo e(Auth::guard('customer')->user()->username); ?></a></li>
                                    <li>
                                        <form action="<?php echo e(route('customer.logout')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="dropdown-item text-danger">Logout</button>
                                        </form>
                                    </li>
                                </ul>
                            </li>
                            <li><a href="<?php echo e(route('public.pesanan')); ?>">Pesanan</a></li>
                        <?php else: ?>
                            
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
    <!-- Header Info Begin -->
    <div class="header-info">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-4">
                    <div class="header-item">
                        <img src="<?php echo e(asset('ecomerce/img/icons/delivery.png')); ?>" alt="">
                        <p>Free shipping on orders over $30 in USA</p>
                    </div>
                </div>
                <div class="col-md-4 text-left text-lg-center">
                    <div class="header-item">
                        <img src="<?php echo e(asset('ecomerce/img/icons/voucher.png')); ?>" alt="">
                        <p>20% Student Discount</p>
                    </div>
                </div>
                <div class="col-md-4 text-left text-xl-right">
                    <div class="header-item">
                    <img src="<?php echo e(asset('ecomerce/img/icons/sales.png')); ?>" alt="">
                    <p>30% off on dresses. Use code: 30OFF</p>
                </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Header Info End -->
    <!-- Header End -->

    <!-- Hero Slider Mulai -->
    <section class="hero-slider">
        <div class="hero-items owl-carousel">
            <div class="single-slider-item set-bg" data-setbg="<?php echo e(asset('ecomerce/img/landing.jpg')); ?>">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1>2025</h1>
                            <h2>Mobil Berkualitas</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="single-slider-item set-bg" data-setbg="<?php echo e(asset('ecomerce/img/2.jpg')); ?>">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1>2025</h1>
                            <h2>serasa mobil Baru</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="single-slider-item set-bg" data-setbg="<?php echo e(asset('ecomerce/img/3.jpg')); ?>">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1>2025</h1>
                            <h2>Bursa resmi NO.1</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Slider Selesai -->

    <!-- Features Section Begin -->
    <section class="features-section spad">
        <div class="features-ads">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="single-features-ads first">
                            <img src="<?php echo e(asset('ecomerce/img/icons/f-delivery.png')); ?>" alt="">
                            <h4>Pengiriman Gratis</h4>
                            <p>Kami memberikan pengiriman gratis untuk setiap pembelian Anda. Nikmati kemudahan berbelanja tanpa biaya tambahan, langsung ke pintu rumah Anda.</p>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="single-features-ads second">
                            <img src="<?php echo e(asset('ecomerce/img/icons/coin.png')); ?>" alt="">
                            <h4>Jaminan Uang Kembali 100%</h4>
                            <p>Jika Anda tidak puas dengan produk kami, kami menawarkan jaminan uang kembali 100%. Belanja dengan rasa aman tanpa khawatir.</p>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="single-features-ads">
                            <img src="<?php echo e(asset('ecomerce/img/icons/chat.png')); ?>" alt="">
                            <h4>Support Online 24/7</h4>
                            <p>Tim customer service kami siap membantu kapan saja, 24 jam sehari, 7 hari seminggu. Kami selalu ada untuk menjawab pertanyaan Anda dan memberikan solusi terbaik.</p>
                        </div>
                    </div>
                </div>                
            </div>
        </div>
        <!-- Fitur Kotak -->
       
    </section>
    <!-- Features Section End -->

    <!-- Produk Terbaru Mulai -->
<section class="latest-products spad" style="background-color: #f8f9fa;">
    <div class="container py-5">
        <div class="product-filter mb-4">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="section-title">
                        <h2>Mobil Bekas Terbaik</h2>
                        <p>Temukan mobil bekas berkualitas dengan harga terbaik</p>
                    </div>
                    <ul class="product-controls">
                        <li data-filter="*">Semua</li>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li data-filter=".<?php echo e(strtolower($category->category_name)); ?>"><?php echo e($category->category_name); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>

        <div class="row" id="product-list">
            <?php $__currentLoopData = $products->where('status', 'approved'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-6 col-sm-6 mix all <?php echo e(strtolower($product->category->category_name ?? 'lainnya')); ?>">
                    <div class="product-card card border rounded-4 shadow-sm mb-4 overflow-hidden bg-white transition">
                        <a href="<?php echo e(route('product.detail', ['id' => $product->product_id])); ?>">
                            <div class="product-image-container">
                                <img src="<?php echo e(asset('img/' . $product->image_url)); ?>" alt="<?php echo e($product->product_name); ?>">
                            </div>
                        </a>
                        <div class="divider mx-3 my-2"></div>
                        <div class="card-body text-center">
                            <h5 class="card-title fw-bold text-capitalize mb-1"><?php echo e($product->product_name); ?></h5>
                            <p class="text-muted mb-1">
                                <?php echo e(ucfirst($product->brand ?? 'Brand Tidak Ada')); ?> • 
                                <?php echo e($product->year ?? 'Tahun Tidak Ada'); ?>

                            </p>
                            <p class="fw-bold text-danger">Rp<?php echo e(number_format($product->price, 0, ',', '.')); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<style>
    .product-card {
        background-color: #ffffff;
        border: 1px solid #e3e3e3;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .product-card:hover {
        transform: scale(1.03);
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
        z-index: 10;
    }

    .product-image-container {
        height: 200px;
        background-color: #ffffff;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
    }

    .product-image-container img {
        max-height: 100%;
        max-width: 100%;
        object-fit: contain;
        transition: transform 0.3s ease;
    }

    .divider {
        height: 1px;
        background-color: #ddd;
    }

    .product-controls li {
        cursor: pointer;
        display: inline-block;
        margin: 0 10px;
        font-weight: 500;
    }
</style>


    <!-- Form Tambah Produk -->
    <section class="product-form-section spad">
        <div class="container">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h1 class="h3 mb-0">Jual Mobilmu Sekarang</h1>
                </div>
                <div class="card-body">
<form action="<?php echo e(route('products.store')); ?>" method="POST" enctype="multipart/form-data" id="productForm">
    <?php echo csrf_field(); ?>

    <div class="row">
        <div class="col-md-6">
            <div class="mb-3">
                <label for="product_name" class="form-label">Nama Produk <span class="text-danger">*</span></label>
                <input type="text" class="form-control <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                       id="product_name" name="product_name" value="<?php echo e(old('product_name')); ?>" required>
                <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">
                <label for="category_id" class="form-label">Kategori <span class="text-danger">*</span></label>
                <select class="form-control <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                        id="category_id" name="category_id" required>
                    <option value="">Pilih Kategori</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->category_id); ?>" 
                            <?php echo e(old('category_id') == $category->category_id ? 'selected' : ''); ?>>
                            <?php echo e($category->category_name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="price" class="form-label">Harga <span class="text-danger">*</span></label>
                        <input type="number" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="price" name="price" value="<?php echo e(old('price')); ?>" required>
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
            </div>
                <div class="col-md-6 d-none">  <!-- Menyembunyikan seluruh div -->
                <div class="mb-3">
                    <input type="hidden" name="stock" value="1">  <!-- Input hidden -->
                    <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            </div>

            <div class="mb-3">
                <label for="warna" class="form-label">Warna</label>
                <input type="text" class="form-control <?php $__errorArgs = ['warna'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                       id="warna" name="warna" value="<?php echo e(old('warna')); ?>">
                <?php $__errorArgs = ['warna'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="col-md-6">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="tahun" class="form-label">Tahun</label>
                        <input type="number" class="form-control <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="tahun" name="tahun" value="<?php echo e(old('tahun')); ?>" 
                               min="1900" max="<?php echo e(date('Y')); ?>">
                        <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="kilometer" class="form-label">Kilometer</label>
                        <input type="number" step="0.01" class="form-control <?php $__errorArgs = ['kilometer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="kilometer" name="kilometer" value="<?php echo e(old('kilometer')); ?>" min="0">
                        <?php $__errorArgs = ['kilometer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <div class="mb-3">
                <label for="description" class="form-label">Deskripsi</label>
                <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                          id="description" name="description" rows="4"><?php echo e(old('description')); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

    <h5 class="mt-4 mb-3">Upload Gambar Produk</h5>
    <div class="row">
        <?php for($i = 1; $i <= 5; $i++): ?>
            <div class="col-md-4 mb-3">
                <div class="card h-100">
                    <div class="card-body">
                        <label for="image<?php echo e($i === 1 ? '' : $i); ?>" class="form-label">
                            Gambar Produk <?php echo e($i); ?> <?php echo e($i === 1 ? '(Utama)' : ''); ?>

                        </label>
                        <input type="file" class="form-control <?php $__errorArgs = ['image'.($i === 1 ? '' : $i)];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="image<?php echo e($i === 1 ? '' : $i); ?>" name="image<?php echo e($i === 1 ? '' : $i); ?>" 
                               accept="image/*">
                        <?php $__errorArgs = ['image'.($i === 1 ? '' : $i)];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <small class="text-muted">Format: jpeg,png,jpg,gif,svg | Max: 2MB</small>
                    </div>
                </div>
            </div>
        <?php endfor; ?>
    </div>

    <div class="d-flex justify-content-between mt-4">
        <a href="<?php echo e(route('public.home')); ?>" class="btn btn-secondary">Kembali</a>
        <button type="submit" class="btn btn-primary" id="submitBtn">Simpan Produk</button>
    </div>
</form>

<?php $__env->startSection('scripts'); ?>
<script>
document.getElementById('productForm').addEventListener('submit', function(e) {
    const requiredFields = this.querySelectorAll('[required]');
    let firstEmptyField = null;
    
    // Cek field yang wajib diisi
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.classList.add('is-invalid');
            
            // Tambahkan error message jika belum ada
            if (!field.nextElementSibling || !field.nextElementSibling.classList.contains('invalid-feedback')) {
                const errorDiv = document.createElement('div');
                errorDiv.className = 'invalid-feedback';
                errorDiv.textContent = 'Field ini wajib diisi';
                field.after(errorDiv);
            }
            
            // Simpan field kosong pertama
            if (!firstEmptyField) {
                firstEmptyField = field;
            }
        }
    });
    
    // Jika ada field yang kosong
    if (firstEmptyField) {
        e.preventDefault();
        firstEmptyField.focus();
        
        // Animasi scroll ke field
        firstEmptyField.scrollIntoView({
            behavior: 'smooth',
            block: 'center'
        });
        
        // Tampilkan alert
        alert('Silakan lengkapi semua field yang wajib diisi');
    } else {
        // Jika semua field terisi, tampilkan loading
        document.getElementById('submitBtn').innerHTML = `
            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
            Menyimpan...
        `;
        document.getElementById('submitBtn').disabled = true;
    }
});

// Hilangkan error saat user mulai mengisi
document.querySelectorAll('[required]').forEach(field => {
    field.addEventListener('input', function() {
        if (this.value.trim()) {
            this.classList.remove('is-invalid');
            if (this.nextElementSibling && this.nextElementSibling.classList.contains('invalid-feedback')) {
                this.nextElementSibling.remove();
            }
        }
    });
});
</script>
<?php $__env->stopSection(); ?>
                </div>
            </div>
        </div>
    </section>


    <!-- Footer Section Begin -->
    <footer class="footer-section spad">
        <div class="container">
            <div class="footer-widget">
                <div class="row">
                    <div class="col-lg-12 col-sm-12">
                        <div class="single-footer-widget">
                            <h4>Cerita tentang T-Shirt</h4>
                            <p>T-Shirt bukan hanya sebuah pakaian, tetapi juga simbol dari gaya hidup, ekspresi diri, dan kenyamanan. Sejarah T-Shirt bermula dari pakaian dalam militer di awal abad ke-20, yang kemudian berevolusi menjadi salah satu pakaian paling populer di seluruh dunia. Kami terinspirasi untuk menghadirkan desain yang tidak hanya menarik, tetapi juga memiliki cerita dan makna. Setiap T-Shirt yang kami ciptakan dirancang dengan perhatian penuh terhadap detail, mulai dari pemilihan bahan berkualitas tinggi hingga proses pembuatan yang ramah lingkungan.</p>
                            <p>Kami percaya bahwa setiap orang berhak untuk tampil gaya tanpa mengorbankan kenyamanan. Oleh karena itu, kami menggunakan bahan-bahan terbaik yang lembut di kulit, tahan lama, dan cocok untuk segala aktivitas. Melalui inovasi desain dan komitmen terhadap kualitas, kami terus berupaya menghadirkan produk yang mencerminkan kepribadian Anda sekaligus memberikan pengalaman terbaik dalam berpakaian.</p>
                        </div>                        
                    </div>
                </div>
            </div>
        </div>
        <div class="social-links-warp">
            <div class="container text-center">
                <div class="social-links">
                    <a href="#" class="instagram"><i class="fa fa-instagram"></i><span>Instagram</span></a>
                    <a href="#" class="facebook"><i class="fa fa-facebook"></i><span>Facebook</span></a>
                    <a href="#" class="twitter"><i class="fa fa-twitter"></i><span>Twitter</span></a>
                    <a href="#" class="youtube"><i class="fa fa-youtube"></i><span>YouTube</span></a>
                </div>
            </div>
            <div class="container text-center pt-3">
                <p>&copy;<script>document.write(new Date().getFullYear());</script> Hak Cipta Dilindungi | Dibuat dengan <i class="icon-heart" aria-hidden="true"></i> oleh <a href="https://colorlib.com" target="_blank">Colorlib</a></p>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->


    <!-- Js Plugins -->
    <script src="<?php echo e(asset('ecomerce/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/jquery.slicknav.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/mixitup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/main.js')); ?>"></script>
    <script>
        $(document).ready(function () {
        var mixer = mixitup('#product-list', {
            selectors: {
                target: '.mix'
            },
            animation: {
                duration: 300
            }
        });
    });
    </script>
</body>

</html><?php /**PATH C:\laragon\www\percobaan5\resources\views/public/home.blade.php ENDPATH**/ ?>