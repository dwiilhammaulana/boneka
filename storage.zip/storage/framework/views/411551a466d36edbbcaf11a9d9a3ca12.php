

<?php $__env->startSection('title', 'Detail Pesan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3">Detail Pesan</h1>
    </div>

    <div class="card">
        <div class="card-body">
            <p><strong>Nama Lengkap:</strong> <?php echo e($contact->first_name); ?> <?php echo e($contact->last_name); ?></p>
            <p><strong>Email:</strong> <?php echo e($contact->email); ?></p>
            <p><strong>Subjek:</strong> <?php echo e($contact->subject); ?></p>
            <p><strong>Pesan:</strong> <?php echo e($contact->message); ?></p>
            <p><strong>Tanggal Kirim:</strong> <?php echo e($contact->created_at->format('d-m-Y H:i')); ?></p>
            
            <a href="<?php echo e(route('contact_us.index')); ?>" class="btn btn-secondary">Kembali ke Daftar Pesan</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\percobaan5\resources\views/contact_us/show.blade.php ENDPATH**/ ?>