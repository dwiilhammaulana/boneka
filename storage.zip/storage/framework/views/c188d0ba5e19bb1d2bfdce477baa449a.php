

<?php $__env->startSection('title', 'Edit Status Pesanan'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="h3">Edit Status Pesanan</h1>

    <form action="<?php echo e(route('orders.update', $order->order_id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <div class="mb-3">
            <label for="status" class="form-label">Status</label>
            <select class="form-control" id="status" name="status" required>
                <?php $__currentLoopData = ['Menunggu', 'Dikonfirmasi', 'DP', 'Lunas', 'Batal']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($option); ?>" <?php echo e($order->status == $option ? 'selected' : ''); ?>>
                        <?php echo e($option); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div class="mb-3">
            <label class="form-label">KTP (Lama)</label>
            <?php if($order->ktp && file_exists(public_path('uploads/ktp/' . $order->ktp))): ?>
                <div class="mb-2">
                    <img src="<?php echo e(asset('uploads/ktp/' . $order->ktp)); ?>" alt="KTP" style="max-width: 300px;">
                </div>
            <?php else: ?>
                <p class="text-muted">Belum ada file KTP.</p>
            <?php endif; ?>
        </div>

        
        <div class="mb-3">
            <label for="ktp_file" class="form-label">Upload KTP Baru (opsional)</label>
            <input type="file" class="form-control" id="ktp_file" name="ktp_file" accept="image/*">
        </div>

        
        <div class="mb-3">
            <label for="stnk" class="form-label">Status STNK</label>
            <select class="form-control" id="stnk" name="stnk">
                <?php $__currentLoopData = ['pending', 'diproses', 'delivered', 'diterima']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($option); ?>" <?php echo e($order->stnk == $option ? 'selected' : ''); ?>>
                        <?php echo e(ucfirst($option)); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div class="mb-3">
            <label for="bpkb" class="form-label">Status BPKB</label>
            <select class="form-control" id="bpkb" name="bpkb">
                <?php $__currentLoopData = ['pending', 'diproses', 'delivered', 'diterima']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($option); ?>" <?php echo e($order->bpkb == $option ? 'selected' : ''); ?>>
                        <?php echo e(ucfirst($option)); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div class="mb-3">
            <label for="logistik" class="form-label">Status Logistik</label>
            <select class="form-control" id="logistik" name="logistik">
                <?php $__currentLoopData = ['request_pickup', 'pickup']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($option); ?>" <?php echo e($order->logistik == $option ? 'selected' : ''); ?>>
                        <?php echo e(ucfirst(str_replace('_', ' ', $option))); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div class="mb-3">
            <label for="sisa_tagihan" class="form-label">Sisa Tagihan</label>
            <input type="number" step="0.01" class="form-control" id="sisa_tagihan" name="sisa_tagihan"
                   value="<?php echo e($order->sisa_tagihan); ?>" required>
        </div>

        <div class="d-flex justify-content-end gap-2 mt-4">
            <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-outline-secondary">Batal</a>
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\percobaan5\resources\views/orders/edit.blade.php ENDPATH**/ ?>