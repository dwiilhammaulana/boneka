

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="invoice-box">

        <h2 class="text-center mb-4">Invoice</h2>

        <div class="row">
            <div class="col-md-6">
                <strong>Dari</strong><br>
                <b>BJM - Berkah Jaya Motor Mobilindo</b><br>
                Arengka 1 No 36 D-E, Jl. Soekarno - Hatta,<br>
                Sidomulyo Tim., Kecamatan Marpoyan, Kota Pekanbaru, Riau 28125<br>
                <strong>No HP:</strong> 0852-6552-7838<br>
                <strong>Email:</strong> info@bjm.com
            </div>
            <div class="col-md-6 text-end">
                <h4><?php echo e(\Carbon\Carbon::parse($order->order_date)->locale('id')->isoFormat('D MMMM YYYY')); ?></h4>
                <strong>Kepada</strong><br>
                <?php echo e($order->customer->full_name); ?><br>
                <strong>No HP:</strong> <?php echo e($order->customer->phone_number); ?><br>
                <strong>Email:</strong> <?php echo e($order->customer->email); ?><br>
            </div>
        </div>

        <div class="row highlight text-white mt-4" style="background-color:#007bff; padding: 10px; border-radius:5px;">
            <div class="col">Invoice: <strong>#<?php echo e($order->order_id); ?></strong></div>
            <div class="col">Order ID: <strong><?php echo e($order->order_id); ?></strong></div>
            <div class="col">Tanggal Pembelian: <strong><?php echo e(date('Y-m-d', strtotime($order->order_date))); ?></strong></div>
            <div class="col">Account: <strong><?php echo e($order->customer->customer_id ?? '-'); ?></strong></div>
        </div>

        <table class="table table-bordered mt-3">
            <thead class="table-light">
                <tr>
                    <th>No</th>
                    <th>Gambar</th>
                    <th>Nama Produk</th>
                    <th>Tipe Produk</th>
                    <th>Warna Produk</th>
                    <th>Jumlah Produk</th>
                    <th>Harga</th>
                </tr>
            </thead>
            <tbody>
                <?php if(!empty($cart)): ?>
                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php if(!empty($item['image'])): ?>
                                    <img src="<?php echo e(asset('img/' . $item['image'])); ?>" alt="<?php echo e($item['name']); ?>" style="width: 60px; height: auto;">
                                <?php else: ?>
                                    <span>-</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($item['name']); ?></td>
                            <td><?php echo e($item['type']); ?></td>
                            <td><?php echo e($item['color']); ?></td>
                            <td><?php echo e($item['quantity']); ?></td>
                            <td>Rp<?php echo e(number_format($item['price'], 0, ',', '.')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center">Keranjang Anda kosong.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <?php
            $totalProduk = 0;
            if(!empty($cart)) {
                foreach($cart as $item) {
                    $totalProduk += $item['price'] * $item['quantity'];
                }
            }
            $total = $totalProduk + $bukti_pesanan;
        ?>

        <div class="mt-4">
            <p><strong>Bayar Sebelum Tanggal:</strong> <span class="text-danger"><?php echo e(\Carbon\Carbon::parse($order->order_date)->addDays(3)->format('d/m/Y')); ?></span></p>
            <p><strong>Jumlah Total Produk:</strong> Rp <?php echo e(number_format($totalProduk, 0, ',', '.')); ?></p>
            <p><strong>Bukti Pesanan:</strong> Rp <?php echo e(number_format($bukti_pesanan, 0, ',', '.')); ?></p>
            <p class="total-box"><strong>Total:</strong> Rp <?php echo e(number_format($total, 0, ',', '.')); ?></p>
        </div>

        <!-- FORM untuk submit data (kalau perlu) -->
        <form action="<?php echo e(route('orders.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="customer_id" value="<?php echo e($order->customer->customer_id); ?>">
            <input type="hidden" name="order_date" value="<?php echo e(date('Y-m-d')); ?>">
            <input type="hidden" name="total_price" value="<?php echo e($total); ?>">
            <input type="hidden" name="bukti_pesanan" value="<?php echo e($bukti_pesanan); ?>">
            <input type="hidden" name="status" value="deal">

            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="hidden" name="order_details[<?php echo e($loop->index); ?>][product_id]" value="<?php echo e($id); ?>">
                <input type="hidden" name="order_details[<?php echo e($loop->index); ?>][quantity]" value="<?php echo e($item['quantity']); ?>">
                <input type="hidden" name="order_details[<?php echo e($loop->index); ?>][price]" value="<?php echo e($item['price']); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\laragon\www\percobaan5\resources\views/invoices/cetak-struk.blade.php ENDPATH**/ ?>