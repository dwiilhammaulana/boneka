

<?php $__env->startSection('title', 'Edit Pesanan'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="h3">Edit Pesanan</h1>

    <form action="<?php echo e(route('orders.update', $order->order_id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label for="customer_id" class="form-label">Pelanggan</label>
            <select class="form-control" id="customer_id" name="customer_id" required>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($customer->customer_id); ?>" <?php echo e($order->customer_id == $customer->customer_id ? 'selected' : ''); ?>>
                        <?php echo e($customer->username); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="order_date" class="form-label">Tanggal Pesan</label>
            <input type="date" class="form-control" id="order_date" name="order_date" value="<?php echo e(old('order_date', $order->order_date)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="status" class="form-label">Status Pesanan</label>
            <select class="form-control" id="status" name="status" required>
                <option value="pending" <?php echo e($order->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                <option value="completed" <?php echo e($order->status == 'completed' ? 'selected' : ''); ?>>Completed</option>
                <option value="cancelled" <?php echo e($order->status == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
            </select>
        </div>

        <h4>Detail Pesanan</h4>
        <div id="orderDetailsContainer">
            <?php $__currentLoopData = $order->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-3" id="orderDetail_<?php echo e($index + 1); ?>">
                    <div class="card-header">
                        <strong>Detail Produk <?php echo e($index + 1); ?></strong>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="product_id_<?php echo e($index + 1); ?>" class="form-label">Produk</label>
                            <select class="form-control" id="product_id_<?php echo e($index + 1); ?>" name="order_details[<?php echo e($index); ?>][product_id]" required>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($product->product_id); ?>" data-price="<?php echo e($product->price); ?>" <?php echo e($detail->product_id == $product->product_id ? 'selected' : ''); ?>>
                                        <?php echo e($product->product_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="quantity_<?php echo e($index + 1); ?>" class="form-label">Jumlah</label>
                            <input type="number" class="form-control" id="quantity_<?php echo e($index + 1); ?>" name="order_details[<?php echo e($index); ?>][quantity]" value="<?php echo e($detail->quantity); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="price_<?php echo e($index + 1); ?>" class="form-label">Harga</label>
                            <input type="number" step="0.01" class="form-control" id="price_<?php echo e($index + 1); ?>" name="order_details[<?php echo e($index); ?>][price]" value="<?php echo e($detail->price); ?>" required readonly>
                        </div>

                        <div class="mb-3">
                            <label for="subtotal_<?php echo e($index + 1); ?>" class="form-label">Subtotal</label>
                            <input type="number" step="0.01" class="form-control" id="subtotal_<?php echo e($index + 1); ?>" name="order_details[<?php echo e($index); ?>][subtotal]" value="<?php echo e($detail->subtotal); ?>" readonly>
                        </div>

                        <button type="button" class="btn btn-danger btn-sm" onclick="removeOrderDetail(<?php echo e($index + 1); ?>)">Hapus Detail</button>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mb-3">
            <label for="total_price" class="form-label">Total Harga</label>
            <input type="number" step="0.01" class="form-control" id="total_price" name="total_price" value="<?php echo e(old('total_price', $order->total_price)); ?>" required readonly>
        </div>
        
        <button type="button" class="btn btn-secondary" id="addOrderDetail">Tambah Detail Produk</button>
        <button type="submit" class="btn btn-primary mt-3">Simpan Pesanan</button>
        <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-secondary">Batal</a>
    </form>

    <script>
        let orderDetailsCount = <?php echo e(count($order->details)); ?>;

        document.getElementById('addOrderDetail').addEventListener('click', function() {
            const orderDetailsContainer = document.getElementById('orderDetailsContainer');
            orderDetailsCount++;

            const newDetail = document.createElement('div');
            newDetail.classList.add('card', 'mb-3');
            newDetail.id = `orderDetail_${orderDetailsCount}`;
            newDetail.innerHTML = `
                <div class="card-header">
                    <strong>Detail Produk ${orderDetailsCount}</strong>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="product_id_${orderDetailsCount}" class="form-label">Produk</label>
                        <select class="form-control" id="product_id_${orderDetailsCount}" name="order_details[${orderDetailsCount - 1}][product_id]" required>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($product->product_id); ?>" data-price="<?php echo e($product->price); ?>"><?php echo e($product->product_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="quantity_${orderDetailsCount}" class="form-label">Jumlah</label>
                        <input type="number" class="form-control" id="quantity_${orderDetailsCount}" name="order_details[${orderDetailsCount - 1}][quantity]" required>
                    </div>

                    <div class="mb-3">
                        <label for="price_${orderDetailsCount}" class="form-label">Harga</label>
                        <input type="number" step="0.01" class="form-control" id="price_${orderDetailsCount}" name="order_details[${orderDetailsCount - 1}][price]" required readonly>
                    </div>

                    <div class="mb-3">
                        <label for="subtotal_${orderDetailsCount}" class="form-label">Subtotal</label>
                        <input type="number" step="0.01" class="form-control" id="subtotal_${orderDetailsCount}" name="order_details[${orderDetailsCount - 1}][subtotal]" readonly>
                    </div>

                    <button type="button" class="btn btn-danger btn-sm" onclick="removeOrderDetail(${orderDetailsCount})">Hapus Detail</button>
                </div>
            `;

            orderDetailsContainer.appendChild(newDetail);
        });

        function removeOrderDetail(id) {
            const detail = document.getElementById(`orderDetail_${id}`);
            detail.remove();
            updateTotalPrice();
        }

        // Fungsi untuk menghitung dan mengupdate harga dan subtotal
        function updatePrices() {
            let totalPrice = 0;
            for (let i = 1; i <= orderDetailsCount; i++) {
                const productSelect = document.getElementById(`product_id_${i}`);
                const quantityInput = document.getElementById(`quantity_${i}`);
                const priceInput = document.getElementById(`price_${i}`);
                const subtotalInput = document.getElementById(`subtotal_${i}`);

                const selectedOption = productSelect.options[productSelect.selectedIndex];
                const productPrice = parseFloat(selectedOption.getAttribute('data-price'));
                const quantity = parseInt(quantityInput.value);

                if (quantity && !isNaN(quantity)) {
                    const subtotal = productPrice * quantity;
                    priceInput.value = productPrice;
                    subtotalInput.value = subtotal.toFixed(2);
                    totalPrice += subtotal;
                }
            }

            // Update total price
            document.getElementById('total_price').value = totalPrice.toFixed(2);
        }

        // Tambahkan event listener untuk input jumlah dan produk
        document.addEventListener('input', function(event) {
            if (event.target.matches('[id^="quantity_"], [id^="product_id_"]')) {
                updatePrices();
            }
        });

        // Initial call to update prices
        updatePrices();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\baju\resources\views/orders/edit.blade.php ENDPATH**/ ?>