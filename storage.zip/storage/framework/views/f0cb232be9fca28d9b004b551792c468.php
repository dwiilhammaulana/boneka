

<?php $__env->startSection('title', 'Tambah Pembayaran'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3">Tambah Pembayaran</h1>
    </div>
    <!-- Form untuk menambahkan pembayaran baru -->
    <form action="<?php echo e(route('pembayaran.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        
        <div class="mb-3">
            <label for="order_id" class="form-label">No Order <span class="text-danger">*</span></label>
<select class="form-control <?php $__errorArgs = ['order_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  
        id="order_id" name="order_id" required>
    <option value="">Pilih No Order</option> 
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <option value="<?php echo e($order->order_id); ?>"
            <?php echo e(old('order_id', $selectedOrderId) == $order->order_id ? 'selected' : ''); ?>>
            <?php echo e($order->order_id); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
            <?php $__errorArgs = ['order_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-3">
            <label for="tanggal_pembayaran" class="form-label">Tanggal Pembayaran <span class="text-danger">*</span></label>
            <input type="date" class="form-control <?php $__errorArgs = ['tanggal_pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                   name="tanggal_pembayaran" id="tanggal_pembayaran" 
                   value="<?php echo e(old('tanggal_pembayaran', date('Y-m-d'))); ?>" required>
            <?php $__errorArgs = ['tanggal_pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <input type="hidden" name="jenis_pembayaran" value="<?php echo e($jenisPembayaran); ?>">

        <div class="mb-3">
            <label class="form-label">Jenis Pembayaran</label>
            <input type="text" class="form-control" value="<?php echo e(ucfirst($jenisPembayaran)); ?>" readonly>
        </div>

        
        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="<?php echo e(route('pembayaran.index')); ?>" class="btn btn-secondary">Batal</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\percobaan5\resources\views/pembayaran/create.blade.php ENDPATH**/ ?>