<!DOCTYPE html>
<html lang="zxx">

<head>
    
    <Style>
       .product-specs-details {
    padding: 10px 0;
}

.spec-item {
    display: flex;
    width: 100%;
    border-bottom: 1px solid #ddd;
    padding: 10px 0;
}

.spec-item:last-child {
    border-bottom: none;
}

.spec-title,
.spec-value {
    width: 50%;
    text-align: left;
    font-size: 16px;
}

.spec-title {
    font-weight: bold;
    color: #333;
}

.spec-value {
    color: #555;
}

    </Style>
    <meta charset="UTF-8">
    <meta name="description" content="Yoga Studio Template">
    <meta name="keywords" content="Yoga, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Violet | Template</title>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- CSS Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/bootstrap.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/font-awesome.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/nice-select.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/owl.carousel.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/magnific-popup.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/slicknav.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/style.css')); ?>" type="text/css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <!-- Page Preloader -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Header Section -->
    <header class="header-section">
        <div class="container-fluid">
            <div class="inner-header">
                <div class="logo">
                    <a href="<?php echo e(route('public.home')); ?>">
                        <img src="<?php echo e(asset('img/Logo.png')); ?>" alt="Logo ASSTORE" class="logo-img">
                    </a>
                </div>
                <div class="header-right">
                    <?php if(auth()->guard('customer')->check()): ?>
                        <a href="<?php echo e(route('public.cart')); ?>">
                            <img src="<?php echo e(asset('ecomerce/img/icons/bag.png')); ?>" alt="">
                            <span><?php echo e(session('cart') ? array_sum(array_column(session('cart'), 'quantity')) : 0); ?></span>
                        </a>
                    <?php endif; ?>
                    <?php if(auth()->guard()->guest()): ?>
                        <a href="<?php echo e(route('login')); ?>">
                            <img src="<?php echo e(asset('ecomerce/img/icons/user.png')); ?>" alt="">
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Navigation Menu -->
                <nav class="main-menu mobile-menu">
                    <ul>
                        <li><a href="<?php echo e(route('public.home')); ?>">Home</a></li>
                        <li><a class="active" href="<?php echo e(route('public.shop')); ?>">Shop</a></li>
                        <li><a href="<?php echo e(route('public.contact')); ?>">Contact</a></li>
                        <?php if(Auth::guard('customer')->check()): ?>
                            <li>
                                <span>Profile</span>
                                <ul class="sub-menu">
                                    <li><a href="<?php echo e(route('customer.profile')); ?>"><?php echo e(Auth::guard('customer')->user()->username); ?></a></li>
                                    <li>
                                        <form action="<?php echo e(route('customer.logout')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="dropdown-item text-danger">Logout</button>
                                        </form>
                                    </li>
                                </ul>
                            </li>
                            <li><a href="<?php echo e(route('public.pesanan')); ?>">Pesanan</a></li>
                        <?php else: ?>
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <!-- Product Page -->
    <section class="product-page">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="product-slider owl-carousel">
                    <?php $__currentLoopData = range(1, 5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $field = $i === 1 ? 'image_url' : 'image_url' . $i;
                            $image = $product->$field ?? null;
                        ?>
                        <?php if($image): ?>
                            <div class="product-img">
                                <figure>
                                    <img src="<?php echo e(asset('img/' . $image)); ?>" alt="<?php echo e($product->product_name); ?>">
                                    <?php if($i === 1 && $product->is_new): ?>
                                        <div class="p-status">Baru</div>
                                    <?php endif; ?>
                                </figure>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="product-content">
                    <h2><?php echo e($product->product_name); ?></h2>
                    <div class="pc-meta">
                        <h5>Rp<?php echo e(number_format($product->price, 0, ',', '.')); ?></h5>
                        <div class="rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                        </div>
                    </div>
                    <p><?php echo e($product->description); ?></p>
                    <ul class="tags">
                        <li><span>Merek :</span> <?php echo e($product->category->category_name ?? 'Tidak ada'); ?></li>
                        <li><span>Warna :</span> <?php echo e($product->warna ?? 'Tidak ada'); ?></li>
                        <li><span>Tahun :</span> <?php echo e($product->tahun ?? 'Tidak ada'); ?></li>
                        <li><span>Kilometer :</span> <?php echo e($product->kilometer ?? 'Tidak ada'); ?> km</li>
                    </ul>

<style>
    .btn-keranjang {
        background-color: #dc3545;      /* Merah */
        color: #fff;                    /* Teks putih */
        border: 1px solid #dc3545;      /* Border merah */
        transition: background-color 0.3s ease, color 0.3s ease;
        font-weight: 600;               /* Sudah semi-bold, jadi tidak berubah saat hover */
    }

    .btn-keranjang:hover {
        background-color: #fff;         /* Putih saat hover */
        color: #dc3545;                 /* Teks merah */
        border: 1px solid #dc3545;      /* Border merah tetap */
        /* font-weight tidak berubah, jadi tidak loncat */
    }
</style>

<form id="addToCartForm" action="<?php echo e(route('public.cart')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="product_id" value="<?php echo e($product->product_id); ?>">

    <div class="d-flex gap-3 mt-3">
        <button type="button" class="btn btn-keranjang" id="btnKeranjang">
            Masukan Keranjang
        </button>

        <a href="<?php echo e(route('checkout')); ?>" class="btn btn-outline-dark">
            Beli Sekarang
        </a>
    </div>
</form>



                    <!-- Include jQuery & SweetAlert -->
                    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

                    <script>
                    $(document).ready(function () {
                        $('#btnKeranjang').on('click', function () {
                            $.ajax({
                                type: 'POST',
                                url: $('#addToCartForm').attr('action'),
                                data: $('#addToCartForm').serialize(),
                                success: function (response) {
                                    Swal.fire({
                                        title: 'Berhasil!',
                                        text: 'Produk telah dimasukkan ke keranjang.',
                                        icon: 'success',
                                        confirmButtonText: 'OK'
                                    });
                                },
                                error: function (xhr) {
                                    Swal.fire({
                                        title: 'Gagal!',
                                        text: 'Terjadi kesalahan. Silakan coba lagi.',
                                        icon: 'error',
                                        confirmButtonText: 'OK'
                                    });
                                }
                            });
                        });
                    });
                    </script>

                </div>
            </div>
        </div>
    </div>
</section>

<!-- Spesifikasi Produk -->
<section class="product-specs spad">
    <div class="container">
        <div class="section-title">
            <h2>Spesifikasi</h2>
        </div>
        <div class="product-specs-details">
            <div class="spec-item">
                <div class="spec-title">Nama Produk</div>
                <div class="spec-value"><?php echo e($product->product_name); ?></div>
            </div>
            <div class="spec-item">
                <div class="spec-title">Kategori</div>
                <div class="spec-value"><?php echo e($product->category->category_name ?? 'Tidak ada'); ?></div>
            </div>
            <div class="spec-item">
                <div class="spec-title">Warna</div>
                <div class="spec-value"><?php echo e($product->warna ?? 'Tidak ada'); ?></div>
            </div>
            <div class="spec-item">
                <div class="spec-title">Tahun</div>
                <div class="spec-value"><?php echo e($product->tahun ?? 'Tidak ada'); ?></div>
            </div>
            <div class="spec-item">
                <div class="spec-title">Kilometer</div>
                <div class="spec-value"><?php echo e($product->kilometer ?? 'Tidak ada'); ?> km</div>
            </div>
        </div>
    </div>
</section>


    <!-- Related Products -->
    <section class="related-products spad">
        <div class="container">
            <div class="section-title">
                <h2>Produk Terkait</h2>
            </div>
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <div class="single-product-item">
                            <a href="<?php echo e(route('product.detail', ['id' => $relatedProduct->product_id])); ?>">
                                <div class="product-img">
                                    <img src="<?php echo e(asset('img/' . $relatedProduct->image_url)); ?>" alt="<?php echo e($relatedProduct->product_name); ?>">
                                    <?php if($relatedProduct->image_url2): ?>
                                        <img src="<?php echo e(asset('img/' . $relatedProduct->image_url2)); ?>" alt="<?php echo e($relatedProduct->product_name); ?>">
                                    <?php endif; ?>
                                </div>
                                <div class="product-text">
                                    <h6><?php echo e($relatedProduct->product_name); ?></h6>
                                    <h5>Rp<?php echo e(number_format($relatedProduct->price, 0, ',', '.')); ?></h5>
                                </div>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>Tidak ada produk terkait.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer-section spad">
        <div class="container">
            <div class="newslatter-form">
                <div class="row">
                    <div class="col-lg-12">
                        <form action="#">
                            <input type="text" placeholder="Your email address">
                            <button type="submit">Subscribe to our newsletter</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="footer-widget">
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="single-footer-widget">
                            <h4>About us</h4>
                            <ul>
                                <li>About Us</li>
                                <li>Community</li>
                                <li>Jobs</li>
                                <li>Shipping</li>
                                <li>Contact Us</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="single-footer-widget">
                            <h4>Customer Care</h4>
                            <ul>
                                <li>Search</li>
                                <li>Privacy Policy</li>
                                <li>2019 Lookbook</li>
                                <li>Shipping & Delivery</li>
                                <li>Gallery</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="single-footer-widget">
                            <h4>Our Services</h4>
                            <ul>
                                <li>Free Shipping</li>
                                <li>Free Returnes</li>
                                <li>Our Franchising</li>
                                <li>Terms and conditions</li>
                                <li>Privacy Policy</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="single-footer-widget">
                            <h4>Information</h4>
                            <ul>
                                <li>Payment methods</li>
                                <li>Times and shipping costs</li>
                                <li>Product Returns</li>
                                <li>Shipping methods</li>
                                <li>Conformity of the products</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="social-links-warp">
            <div class="container">
                <div class="social-links">
                    <a href="#" class="instagram"><i class="fa fa-instagram"></i><span>instagram</span></a>
                    <a href="#" class="pinterest"><i class="fa fa-pinterest"></i><span>pinterest</span></a>
                    <a href="#" class="facebook"><i class="fa fa-facebook"></i><span>facebook</span></a>
                    <a href="#" class="twitter"><i class="fa fa-twitter"></i><span>twitter</span></a>
                    <a href="#" class="youtube"><i class="fa fa-youtube"></i><span>youtube</span></a>
                    <a href="#" class="tumblr"><i class="fa fa-tumblr-square"></i><span>tumblr</span></a>
                </div>
            </div>
            <div class="container text-center pt-5">
                <p>&copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart color-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a></p>
            </div>
        </div>
    </footer>

    <!-- JS Plugins -->
    <script src="<?php echo e(asset('ecomerce/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/jquery.slicknav.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/mixitup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/main.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\laragon\www\percobaan5\resources\views/public/product.blade.php ENDPATH**/ ?>