

<?php $__env->startSection('title', 'Mobil yang Dijual Customer'); ?>

<?php $__env->startSection('content'); ?>

<style>
    @media print {
        body * {
            visibility: hidden;
        }

        .print-area, .print-area * {
            visibility: visible;
        }

        .print-area {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
        }

        .no-print {
            display: none !important;
        }
    }
</style>

<div class="container">
    
    <form method="GET" class="row g-3 mb-4 no-print">
        <div class="col-md-3">
            <label>Tanggal</label>
            <input type="date" name="tanggal" value="<?php echo e(request('tanggal')); ?>" class="form-control">
        </div>
        <div class="col-md-3">
            <label>Bulan</label>
            <input type="number" name="bulan" value="<?php echo e(request('bulan')); ?>" class="form-control" placeholder="1-12">
        </div>
        <div class="col-md-3">
            <label>Tahun</label>
            <input type="number" name="tahun" value="<?php echo e(request('tahun')); ?>" class="form-control" placeholder="2025">
        </div>
        <div class="col-md-3 d-flex align-items-end">
            <button class="btn btn-primary w-100">Filter</button>
        </div>
    </form>

    <?php if($products->isEmpty()): ?>
        <div class="alert alert-warning no-print">Tidak ada mobil yang dijual customer pada periode ini.</div>
    <?php else: ?>
        <div class="print-area">
            <h3 class="text-center mb-3">Laporan Mobil yang Dijual Customer</h3>

            
            <p><strong>Filter Tanggal:</strong>
                <?php if(request('tanggal')): ?>
                    <?php echo e(\Carbon\Carbon::parse(request('tanggal'))->format('d M Y')); ?>

                <?php elseif(request('bulan') && request('tahun')): ?>
                    Bulan <?php echo e(request('bulan')); ?> Tahun <?php echo e(request('tahun')); ?>

                <?php elseif(request('tahun')): ?>
                    Tahun <?php echo e(request('tahun')); ?>

                <?php else: ?>
                    Semua Data
                <?php endif; ?>
            </p>

            
            <table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>Tanggal Beli</th>
                        <th>Nama Mobil</th>
                        <th>Merek</th>        
                        <th class="text-end">Harga</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $totalHarga = 0; ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $totalHarga += $m->price; ?>
                        <tr>
                            <td><?php echo e(\Carbon\Carbon::parse($m->created_at)->format('d M Y')); ?></td>
                            <td><?php echo e($m->product_name); ?></td>
                            <td><?php echo e($m->category_name); ?></td>
                            <td class="text-end">Rp <?php echo e(number_format($m->price, 0, ',', '.')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr class="table-success fw-bold">
                        <td colspan="3" class="text-end">Total Harga Mobil:</td>
                        <td class="text-end">Rp <?php echo e(number_format($totalHarga, 0, ',', '.')); ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    <?php endif; ?>

    
    <div class="text-end mt-4 no-print">
        <button type="button" onclick="window.print()" class="btn btn-success">Cetak Laporan</button>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\percobaan5\resources\views/laporan/mobil_customer.blade.php ENDPATH**/ ?>