<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Invoice - BJM Mobilindo</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/bootstrap.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/font-awesome.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/nice-select.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/owl.carousel.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/magnific-popup.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/slicknav.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/style.css')); ?>" type="text/css">
<style>
body {
    background-color: #f8f9fa;
}
.navbar-brand span {
    font-weight: bold;
    color: #d90429;
}
.invoice-box {
    background: white;
    padding: 30px;
    margin-top: 30px;
    border-radius: 10px;
    box-shadow: 0 0 10px #ccc;
}
.highlight {
    background-color: #d90429;
    color: white;
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 20px;
}
.total-box {
    font-size: 1.3rem;
    font-weight: bold;
}
.table > :not(:first-child) {
    border-top: 2px solid #dee2e6;
}
</style>
</head>
<body>

<!-- NAVBAR -->


<!-- resources/views/partials/header.blade.php -->

<header class="header-section">
    <div class="container-fluid">
        <div class="inner-header">
            <div class="logo">
                <a href="<?php echo e(route('public.home')); ?>"><h4>ASSTORE</h4></a>
            </div>
            <div class="header-right">
                <?php if(auth()->guard('customer')->check()): ?>
                    <a class="active" href="<?php echo e(route('public.cart')); ?>">
                        <img src="<?php echo e(asset('ecomerce/img/icons/bag.png')); ?>" alt="">
                        <span><?php echo e(session('cart') ? array_sum(array_column(session('cart'), 'quantity')) : 0); ?></span>
                    </a>
                <?php endif; ?>

                <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('login')); ?>">
                        <img src="<?php echo e(asset('ecomerce/img/icons/user.png')); ?>" alt="">
                    </a>
                <?php endif; ?>
            </div>

            <nav class="main-menu mobile-menu">
                <ul>
                    <li><a href="<?php echo e(route('public.home')); ?>">Home</a></li>
                    <li><a href="<?php echo e(route('public.shop')); ?>">Shop</a></li>
                    <li><a href="<?php echo e(route('public.contact')); ?>">Contact</a></li>

                    <?php if(auth()->guard('customer')->check()): ?>
                        <li><span>Profile</span>
                            <ul class="sub-menu">
                                <li><a href="<?php echo e(route('customer.profile')); ?>"><?php echo e(Auth::guard('customer')->user()->username); ?></a></li>
                                <li>
                                    <form action="<?php echo e(route('customer.logout')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="dropdown-item text-danger">Logout</button>
                                    </form>
                                </li>
                            </ul>
                        </li>
                        <li><a href="<?php echo e(route('public.pesanan')); ?>">Pesanan</a></li>
                    <?php else: ?>
                        <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>
</header>

<div class="header-info">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4">
                <div class="header-item">
                    <img src="img/icons/delivery.png" alt="">
                    <p>Free shipping on orders over $30 in USA</p>
                </div>
            </div>
            <div class="col-md-4 text-left text-lg-center">
                <div class="header-item">
                    <img src="img/icons/voucher.png" alt="">
                    <p>20% Student Discount</p>
                </div>
            </div>
            <div class="col-md-4 text-left text-xl-right">
                <div class="header-item">
                    <img src="img/icons/sales.png" alt="">
                    <p>30% off on dresses. Use code: 30OFF</p>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- INVOICE CONTENT -->
<div class="container">
<div class="invoice-box">

<h2 class="text-center mb-4">Invoice</h2>

<div class="row">
    <div class="col-md-6">
        <strong>Dari</strong><br>
        <b>BJM - Berkah Jaya Motor Mobilindo</b><br>
        Arengka 1 No 36 D-E, Jl. Soekarno - Hatta,<br>
        Sidomulyo Tim., Kecamatan Marpoyan, Kota Pekanbaru, Riau 28125<br>
        <strong>No HP:</strong> 0852-6552-7838<br>
        <strong>Email:</strong> info@bjm.com
    </div>
    <div class="col-md-6 text-end">
        <h4><?php echo e(\Carbon\Carbon::now()->locale('id')->isoFormat('D MMMM YYYY')); ?></h4>
        <strong>Kepada</strong><br>
        <?php echo e(Auth::guard('customer')->user()->username); ?><br>
        <strong>No HP:</strong> <?php echo e(Auth::guard('customer')->user()->phone_number); ?><br>
        <strong>Email:</strong> <?php echo e(Auth::guard('customer')->user()->email); ?><br>
    </div>
</div>

<div class="row highlight text-white mt-4">
    <div class="col">Invoice: <strong>#r4HyuBS9xV</strong></div>
    <div class="col">Order ID: <strong>p8pn8GsKDR</strong></div>
    <?php
    use Carbon\Carbon;
?>

<div class="col">Tanggal Pembelian: <strong><?php echo e(Carbon::now()->translatedFormat('d F Y')); ?></strong></div>

    <div class="col">Account: <strong><?php echo e(Auth::guard('customer')->user()->customer_id); ?></strong></div>
</div>

<table class="table table-bordered mt-3">
    <thead class="table-light">
        <tr>
            <th>No</th>
            <th>Gambar</th>
            <th>Nama Produk</th>
            <th>Tipe Produk</th>
            <th>Warna Produk</th>
            <th>Jumlah Produk</th>
            <th>Harga</th>
        </tr>
    </thead>
    <tbody>
        <?php if(!empty($cart)): ?>
            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td>
                        <?php if(!empty($item['image'])): ?>
                            <img src="<?php echo e(asset('img/' . $item['image'])); ?>" alt="<?php echo e($item['name']); ?>" style="width: 60px; height: auto;">
                        <?php else: ?>
                            <span>-</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($item['name']); ?></td>
                    <td><?php echo e($item['kilometer'] ?? '-'); ?></td>
                    <td><?php echo e($item['warna']); ?></td>
                    <td><?php echo e($item['quantity']); ?></td>
                    <td>Rp<?php echo e(number_format($item['price'], 0, ',', '.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr>
                <td colspan="7" class="text-center">Keranjang Anda kosong.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<?php
    $bukti_pesanan = 500000;
    $totalProduk = 0;
    if(!empty($cart)) {
        foreach($cart as $item) {
            $totalProduk += $item['price'] * $item['quantity'];
        }
    }
    $total = $totalProduk + $bukti_pesanan;
?>

<div class="mt-4">
    <?php
    $bayar_sebelum = \Carbon\Carbon::now()->addDays(7)->locale('id')->isoFormat('D MMMM YYYY');
?>

<p><strong>Bayar Sebelum Tanggal:</strong> <span class="text-danger"><?php echo e($bayar_sebelum); ?></span></p>

    <p><strong>Jumlah Total Produk:</strong> Rp <?php echo e(number_format($totalProduk, 0, ',', '.')); ?></p>
    <p><strong>Bukti Pesanan:</strong> Rp <?php echo e(number_format($bukti_pesanan, 0, ',', '.')); ?></p>
    <p class="total-box"><strong>Total:</strong> Rp <?php echo e(number_format($total, 0, ',', '.')); ?></p>
</div>

<!-- FORM untuk submit data -->
<form action="<?php echo e(route('orders.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <!-- Hidden Inputs -->
    <input type="hidden" name="customer_id" value="<?php echo e(Auth::guard('customer')->user()->customer_id); ?>">
    <input type="hidden" name="order_date" value="<?php echo e(date('Y-m-d')); ?>">
    <input type="hidden" name="total_price" value="<?php echo e($total); ?>">
    <input type="hidden" name="bukti_pesanan" value="<?php echo e($bukti_pesanan); ?>">
    <input type="hidden" name="status" value="Menunggu">

    <!-- Order Details -->
    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <input type="hidden" name="order_details[<?php echo e($loop->index); ?>][product_id]" value="<?php echo e($id); ?>">
        <input type="hidden" name="order_details[<?php echo e($loop->index); ?>][quantity]" value="<?php echo e($item['quantity']); ?>">
        <input type="hidden" name="order_details[<?php echo e($loop->index); ?>][price]" value="<?php echo e($item['price']); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Upload Foto KTP -->
    <div class="mb-3">
        <label for="ktp" class="form-label"><strong>Upload Foto KTP</strong></label>
        <input type="file" class="form-control" id="ktp" name="ktp" accept="image/*" required>
    </div>

    <!-- Tombol Submit -->
    <div class="mt-4 text-center">
        <button type="submit" class="btn btn-success btn-lg">buat pesanan</button>
    </div>
</form>

</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\percobaan5\resources\views/public/checkout.blade.php ENDPATH**/ ?>