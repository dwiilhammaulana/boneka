

<?php $__env->startSection('title', 'Detail Admin'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3">Detail Admin</h1>
        <a href="<?php echo e(route('admin.index')); ?>" class="btn btn-secondary">Kembali ke Daftar Admin</a>
    </div>

    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Detail Admin: <?php echo e($admin->username); ?></h5>
        </div>
        <div class="card-body">
            <div class="mb-3">
                <strong>Username:</strong> <?php echo e($admin->username); ?>

            </div>
            <div class="mb-3">
                <strong>Email:</strong> <?php echo e($admin->email ?? '-'); ?>

            </div>
            <div class="mb-3">
                <strong>Nama Lengkap:</strong> <?php echo e($admin->full_name ?? '-'); ?>

            </div>
            <div class="mb-3">
                <strong>Nomor Telepon:</strong> <?php echo e($admin->phone_number ?? '-'); ?>

            </div>
            <!-- Jika Anda ingin menambahkan tanggal pembuatan atau lainnya -->
            <div class="mb-3">
                <strong>Tanggal Dibuat:</strong> <?php echo e($admin->created_at->format('d M Y')); ?>

            </div>
        </div>

        <div class="card-footer">
            <!-- Tombol Edit -->
            <a href="<?php echo e(route('admin.edit', $admin->admin_id)); ?>" class="btn btn-warning">Edit Admin</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\baju\resources\views/admin/show.blade.php ENDPATH**/ ?>