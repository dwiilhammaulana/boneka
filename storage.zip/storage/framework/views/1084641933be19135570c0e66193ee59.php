

<?php $__env->startSection('title', 'Daftar Admin'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3">Daftar Admin</h1>
        <a href="<?php echo e(route('admin.create')); ?>" class="btn btn-primary">Tambah Admin</a>
    </div>

    <!-- Table -->
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Daftar Admin</h5>
        </div>
        <div class="card-body">
            <table class="table table-striped table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Nama Lengkap</th>
                        <th>Nomor Telepon</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  <!-- Looping melalui masing-masing admin -->
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($admin->username); ?></td>
                        <td><?php echo e($admin->email); ?></td>
                        <td><?php echo e($admin->full_name); ?></td>
                        <td><?php echo e($admin->phone_number); ?></td>
                        <td>
                            <!-- Tombol untuk melihat detail admin -->
                            <a href="<?php echo e(route('admin.show', $admin->admin_id)); ?>" class="btn btn-info btn-sm">Detail</a>
                            <!-- Tombol untuk mengedit admin -->
                            <a href="<?php echo e(route('admin.edit', $admin->admin_id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                            <!-- Form untuk menghapus admin -->
                            <form action="<?php echo e(route('admin.destroy', $admin->admin_id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\jual_beli_mobil\resources\views/admin/index.blade.php ENDPATH**/ ?>