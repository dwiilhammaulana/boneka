

<?php $__env->startSection('title', 'Daftar Pembayaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3">Daftar Pembayaran</h1>
    <a href="<?php echo e(route('pembayaran.create')); ?>" class="btn btn-primary">Tambah Pembayaran</a>
</div>

<!-- Tabel -->
<div class="card shadow-sm">
    <div class="card-header bg-primary text-white">
        <h5 class="mb-0">Data Pembayaran</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-bordered align-middle">
                <thead class="table-dark text-center">
                    <tr>
                        <th>No</th>
                        <th>Order ID</th>
                        <th>Tanggal Pembayaran</th>
                        <th>Jumlah Bayar</th>
                        <th>Metode</th>
                        <th class="text-center">Bukti Bayar</th>
                        <th class="text-center">Aksi</th>   
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembayaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($pembayaran->order_id); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($pembayaran->tanggal_pembayaran)->format('d-m-Y')); ?></td>
                        <td>Rp <?php echo e(number_format($pembayaran->jumlah_bayar, 0, ',', '.')); ?></td>
                        <td><?php echo e(ucfirst($pembayaran->metode)); ?></td>
                        <td class="text-center">
                            <?php if($pembayaran->metode === 'transfer' && $pembayaran->bukti_bayar): ?>
                                <img src="<?php echo e(asset('storage/bukti_bayar/' . $pembayaran->bukti_bayar)); ?>"
                                     alt="Bukti Bayar"
                                     style="max-width: 100px; cursor: pointer; border-radius: 6px;"
                                     data-bs-toggle="modal"
                                     data-bs-target="#modalBukti<?php echo e($loop->iteration); ?>">
                                
                                <!-- Modal -->
                                <div class="modal fade" id="modalBukti<?php echo e($loop->iteration); ?>" tabindex="-1" aria-labelledby="modalLabel<?php echo e($loop->iteration); ?>" aria-hidden="true">
                                  <div class="modal-dialog modal-dialog-centered modal-lg">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title" id="modalLabel<?php echo e($loop->iteration); ?>">Bukti Pembayaran</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                      </div>
                                      <div class="modal-body text-center">
                                        <img src="<?php echo e(asset('storage/bukti_bayar/' . $pembayaran->bukti_bayar)); ?>"
                                             alt="Bukti Bayar Besar"
                                             class="img-fluid rounded shadow">
                                      </div>
                                    </div>
                                  </div>
                                </div>
                            <?php else: ?>
                                Tidak ada
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <a href="<?php echo e(route('pembayaran.show', $pembayaran->id_pembayaran)); ?>" class="btn btn-info btn-sm">Detail</a>
                            <a href="<?php echo e(route('pembayaran.edit', $pembayaran->id_pembayaran)); ?>" class="btn btn-warning btn-sm">Edit</a>
                            <form action="<?php echo e(route('pembayaran.destroy', $pembayaran->id_pembayaran)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\percobaan5\resources\views/pembayaran/index.blade.php ENDPATH**/ ?>