

<?php $__env->startSection('title', 'Detail Kategori'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3">Detail Kategori</h1>
        <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-secondary">Kembali ke Daftar Kategori</a>
    </div>

    <!-- Tampilkan detail kategori -->
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Detail Kategori: <?php echo e($category->category_name); ?></h5>
        </div>
        <div class="card-body">
            <div class="mb-3">
                <strong>Nama Kategori:</strong> <?php echo e($category->category_name); ?>

            </div>
            <div class="mb-3">
                <strong>Deskripsi:</strong> <?php echo e($category->description ?? '-'); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\baju\resources\views/categories/show.blade.php ENDPATH**/ ?>