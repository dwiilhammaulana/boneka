<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Yoga Studio Template">
    <meta name="keywords" content="Yoga, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Violet | Template</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900&display=swap"
        rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/bootstrap.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/font-awesome.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/nice-select.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/owl.carousel.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/magnific-popup.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/slicknav.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/style.css')); ?>" type="text/css">
</head>

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>
    
    <!-- Search model -->
	<div class="search-model">
		<div class="h-100 d-flex align-items-center justify-content-center">
			<div class="search-close-switch">+</div>
			<form class="search-model-form">
				<input type="text" id="search-input" placeholder="Search here.....">
			</form>
		</div>
	</div>
	<!-- Search model end -->
    <!-- Header Section Begin -->
    <header class="header-section">
        <div class="container-fluid">
            <div class="inner-header">
                <div class="logo">
                    <a href="<?php echo e(route('public.home')); ?>"><h4>ASSTORE</h4></a>
                </div>
                <div class="header-right">
                    <!-- Menampilkan icon profile untuk pengguna yang sudah login -->
                    <?php if(auth()->guard('customer')->check()): ?>
                        <a href="<?php echo e(route('public.cart')); ?>">
                            <img src="<?php echo e(asset('ecomerce/img/icons/bag.png')); ?>" alt="">
                            <span><?php echo e(session('cart') ? array_sum(array_column(session('cart'), 'quantity')) : 0); ?></span> <!-- Menampilkan jumlah barang di cart -->
                        </a>
                    <?php endif; ?>

                    <!-- Menampilkan keranjang belanja untuk pengguna yang sudah login -->
                    <?php if(auth()->guard()->guest()): ?>
                        <a href="<?php echo e(route('login')); ?>">
                            <img src="<?php echo e(asset('ecomerce/img/icons/user.png')); ?>" alt=""> <!-- Icon untuk login -->
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Menu Navigasi -->
                <nav class="main-menu mobile-menu" style="center">
                    <ul>
                        <li><a href="<?php echo e(route('public.home')); ?>">Home</a></li>
                        <li><a href="<?php echo e(route('public.shop')); ?>">Shop</a></li>
                        <li><a href="<?php echo e(route('public.contact')); ?>">Contact</a></li>
                        
                        <?php if(Auth::guard('customer')->check()): ?>
                            
                            <li><span>Profile</span>
                                <ul class="sub-menu">
                                    <li><a href="<?php echo e(route('customer.profile')); ?>"><?php echo e(Auth::guard('customer')->user()->username); ?></a></li>
                                    <li>
                                        <form action="<?php echo e(route('customer.logout')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="dropdown-item text-danger">Logout</button>
                                        </form>
                                    </li>
                                </ul>
                            </li>
                            <li><a href="<?php echo e(route('public.pesanan')); ?>">Pesanan</a></li>
                        <?php else: ?>
                            
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
    <!-- Header Info Begin -->
    <div class="header-info">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-4">
                    <div class="header-item">
                        <img src="img/icons/delivery.png" alt="">
                        <p>Free shipping on orders over $30 in USA</p>
                    </div>
                </div>
                <div class="col-md-4 text-left text-lg-center">
                    <div class="header-item">
                        <img src="img/icons/voucher.png" alt="">
                        <p>20% Student Discount</p>
                    </div>
                </div>
                <div class="col-md-4 text-left text-xl-right">
                    <div class="header-item">
                    <img src="img/icons/sales.png" alt="">
                    <p>30% off on dresses. Use code: 30OFF</p>
                </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Header Info End -->
    <!-- Header End -->

    <!-- Page Add Section Begin -->
    <section class="page-add">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="page-breadcrumb">
                        <h2>Checkout<span>.</span></h2>
                    </div>
                </div>
                <div class="col-lg-8">
                    <img src="img/add.jpg" alt="">
                </div>
            </div>
        </div>
    </section>
    <!-- Page Add Section End -->

    <!-- Halaman Total Keranjang Mulai -->
    <section class="cart-total-page spad">
        <div class="container">
            <form action="<?php echo e(route('orders.storee')); ?>" method="POST" class="checkout-form">
                <?php echo csrf_field(); ?>
                <!-- Informasi Anda -->
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <div class="info-box p-4 mb-4 shadow-sm border rounded">
                            <h3 class="mb-4 text-primary">Informasi Anda</h3>
                            <!-- Input Nama -->
                            <div class="form-group">
                                <label class="font-weight-bold">Nama*</label>
                                <input type="text" name="customer_name" value="<?php echo e(Auth::guard('customer')->user()->username); ?>" class="form-control" readonly>
                                <input type="hidden" name="customer_id" value="<?php echo e(Auth::guard('customer')->user()->customer_id); ?>" class="form-control" readonly>
                            </div>
                            <div class="form-group">
                                <label class="font-weight-bold">Alamat</label>
                                <input type="text" name="addres" value="<?php echo e(Auth::guard('customer')->user()->address); ?>" class="form-control" readonly>
                            </div>
                            <!-- Input Tanggal Pesanan -->
                            <div class="form-group">
                                <label class="font-weight-bold">Tanggal Pesanan*</label>
                                <input type="date" name="order_date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" readonly required>
                            </div>
                            <!-- Input Status -->
                            <input type="hidden" name="status" value="pending">
                        </div>
                    </div>
                </div>
                <!-- Detail Pesanan -->
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <div class="order-box p-4 mb-4 shadow-sm border rounded">
                            <h3 class="mb-4 text-primary">Detail Pesanan</h3>
                            <table class="table table-striped">
                                <thead class="thead-light">
                                    <tr>
                                        <th>Produk</th>
                                        <th>Jumlah</th>
                                        <th>Harga</th>
                                    </tr>
                                </thead>
                                <tbody id="order-details">
                                    <?php if(!empty($cart)): ?>
                                        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <input type="hidden" name="order_details[<?php echo e($loop->index); ?>][product_id]" value="<?php echo e($id); ?>">
                                                    <span><?php echo e($item['name']); ?></span>
                                                </td>
                                                <td>
                                                    <input type="number" name="order_details[<?php echo e($loop->index); ?>][quantity]" value="<?php echo e($item['quantity']); ?>" class="form-control" readonly>
                                                </td>
                                                <td>
                                                    <input type="number" name="order_details[<?php echo e($loop->index); ?>][price]" value="<?php echo e($item['price']); ?>" class="form-control" step="0.01" readonly>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="3" class="text-center">Keranjang Anda kosong.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <!-- Total Harga -->
                            <div class="form-group mt-3">
                                <label class="font-weight-bold">Total Harga</label>
                                <input type="number" name="total_price" class="form-control" step="0.01" required readonly>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tombol Submit -->
                <div class="row mt-4">
                    <div class="col-lg-12 text-center">
                        <button type="submit" class="btn btn-primary btn-lg px-5 py-2">Kirim Pesanan</button>
                    </div>
                </div>
            </form>
        </div>
    </section>
    <!-- Halaman Total Keranjang Selesai -->

    <!-- Footer Section Begin -->
    <footer class="footer-section spad">
        <div class="container">
            <div class="footer-widget">
                <div class="row">
                    <div class="col-lg-12 col-sm-12">
                        <div class="single-footer-widget">
                            <h4>Cerita tentang T-Shirt</h4>
                            <p>T-Shirt bukan hanya sebuah pakaian, tetapi juga simbol dari gaya hidup, ekspresi diri, dan kenyamanan. Sejarah T-Shirt bermula dari pakaian dalam militer di awal abad ke-20, yang kemudian berevolusi menjadi salah satu pakaian paling populer di seluruh dunia. Kami terinspirasi untuk menghadirkan desain yang tidak hanya menarik, tetapi juga memiliki cerita dan makna. Setiap T-Shirt yang kami ciptakan dirancang dengan perhatian penuh terhadap detail, mulai dari pemilihan bahan berkualitas tinggi hingga proses pembuatan yang ramah lingkungan.</p>
                            <p>Kami percaya bahwa setiap orang berhak untuk tampil gaya tanpa mengorbankan kenyamanan. Oleh karena itu, kami menggunakan bahan-bahan terbaik yang lembut di kulit, tahan lama, dan cocok untuk segala aktivitas. Melalui inovasi desain dan komitmen terhadap kualitas, kami terus berupaya menghadirkan produk yang mencerminkan kepribadian Anda sekaligus memberikan pengalaman terbaik dalam berpakaian.</p>
                        </div>                        
                    </div>
                </div>
            </div>
        </div>
        <div class="social-links-warp">
            <div class="container text-center">
                <div class="social-links">
                    <a href="#" class="instagram"><i class="fa fa-instagram"></i><span>Instagram</span></a>
                    <a href="#" class="facebook"><i class="fa fa-facebook"></i><span>Facebook</span></a>
                    <a href="#" class="twitter"><i class="fa fa-twitter"></i><span>Twitter</span></a>
                    <a href="#" class="youtube"><i class="fa fa-youtube"></i><span>YouTube</span></a>
                </div>
            </div>
            <div class="container text-center pt-3">
                <p>&copy;<script>document.write(new Date().getFullYear());</script> Hak Cipta Dilindungi | Dibuat dengan <i class="icon-heart" aria-hidden="true"></i> oleh <a href="https://colorlib.com" target="_blank">Colorlib</a></p>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="<?php echo e(asset('ecomerce/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/jquery.slicknav.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/mixitup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/main.js')); ?>"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        // Fungsi untuk menghitung total harga
        function calculateTotalPrice() {
            let total = 0;

            // Ambil semua elemen input harga dan jumlah
            const rows = document.querySelectorAll('#order-details tr');

            rows.forEach(row => {
                const priceInput = row.querySelector('input[name*="[price]"]');
                const quantityInput = row.querySelector('input[name*="[quantity]"]');

                if (priceInput && quantityInput) {
                    const price = parseFloat(priceInput.value) || 0;
                    const quantity = parseInt(quantityInput.value) || 0;

                    // Tambahkan ke total
                    total += price * quantity;
                }
            });

            // Masukkan hasil ke input total_price
            const totalPriceInput = document.querySelector('input[name="total_price"]');
            if (totalPriceInput) {
                totalPriceInput.value = total.toFixed(2); // Format dengan dua desimal
            }
        }

        // Hitung ulang total harga setiap kali halaman dimuat
        calculateTotalPrice();

        // Tambahkan event listener jika ada perubahan pada harga atau jumlah
        const inputs = document.querySelectorAll('#order-details input[name*="[quantity]"], #order-details input[name*="[price]"]');
        inputs.forEach(input => {
            input.addEventListener('input', calculateTotalPrice);
        });
    });
</script>

</body>

</html><?php /**PATH C:\laragon\www\baju\resources\views/public/checkout.blade.php ENDPATH**/ ?>