 

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Pembayaran Angsuran</h2>

    <div class="card">
        <div class="card-body">
            <p><strong>Order ID:</strong> <?php echo e($orders->order_id); ?></p>
            <p><strong>Nama Pelanggan:</strong> <?php echo e($orders->customer_name ?? 'Nama tidak tersedia'); ?></p>
            <p><strong>Total Tagihan:</strong> Rp<?php echo e(number_format($orders->total_tagihan ?? 0, 0, ',', '.')); ?></p>

            <form action="<?php echo e(route('pembayaran.store', $orders->order_id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                
                <div class="mb-3">
                    <label for="jumlah_bayar" class="form-label">Jumlah Bayar</label>
                    <input type="number" name="jumlah_bayar" id="jumlah_bayar" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="metode_pembayaran" class="form-label">Metode Pembayaran</label>
                    <select name="metode_pembayaran" id="metode_pembayaran" class="form-select" required>
                        <option value="">-- Pilih Metode --</option>
                        <option value="transfer">Transfer Bank</option>
                        <option value="tunai">Tunai</option>
                        <option value="qris">QRIS</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-success">Bayar Sekarang</button>
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\percobaan5\resources\views/public/pembayaran.blade.php ENDPATH**/ ?>