<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Yoga Studio Template">
    <meta name="keywords" content="Yoga, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SECLOTH</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900&display=swap"
        rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/bootstrap.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/font-awesome.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/nice-select.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/owl.carousel.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/magnific-popup.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/slicknav.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/style.css')); ?>" type="text/css">
</head>

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>
    
    <!-- Search model -->
	<div class="search-model">
		<div class="h-100 d-flex align-items-center justify-content-center">
			<div class="search-close-switch">+</div>
			<form class="search-model-form">
				<input type="text" id="search-input" placeholder="Search here.....">
			</form>
		</div>
	</div>
	<!-- Search model end -->

    <!-- Header Section Begin -->
    <header class="header-section">
        <div class="container-fluid">
            <div class="inner-header">
                <div class="logo">
                    <a href="<?php echo e(route('public.home')); ?>"><h4>ASSTORE</h4></a>
                </div>
                <div class="header-right">
                    <!-- Menampilkan icon profile untuk pengguna yang sudah login -->
                    <?php if(auth()->guard('customer')->check()): ?>
                        <a href="<?php echo e(route('public.cart')); ?>">
                            <img src="<?php echo e(asset('ecomerce/img/icons/bag.png')); ?>" alt="">
                            <span><?php echo e(session('cart') ? array_sum(array_column(session('cart'), 'quantity')) : 0); ?></span> <!-- Menampilkan jumlah barang di cart -->
                        </a>
                    <?php endif; ?>

                    <!-- Menampilkan keranjang belanja untuk pengguna yang sudah login -->
                    <?php if(auth()->guard()->guest()): ?>
                        <a href="<?php echo e(route('login')); ?>">
                            <img src="<?php echo e(asset('ecomerce/img/icons/user.png')); ?>" alt=""> <!-- Icon untuk login -->
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Menu Navigasi -->
                <nav class="main-menu mobile-menu" style="center">
                    <ul>
                        <li><a class="active" href="<?php echo e(route('public.home')); ?>">Home</a></li>
                        <li><a href="<?php echo e(route('public.shop')); ?>">Shop</a></li>
                        <li><a href="<?php echo e(route('public.contact')); ?>">Contact</a></li>
                        
                        <?php if(Auth::guard('customer')->check()): ?>
                            
                            <li><span>Profile</span>
                                <ul class="sub-menu">
                                    <li><a href="<?php echo e(route('customer.profile')); ?>"><?php echo e(Auth::guard('customer')->user()->username); ?></a></li>
                                    <li>
                                        <form action="<?php echo e(route('customer.logout')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="dropdown-item text-danger">Logout</button>
                                        </form>
                                    </li>
                                </ul>
                            </li>
                            <li><a href="<?php echo e(route('public.pesanan')); ?>">Pesanan</a></li>
                        <?php else: ?>
                            
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
    <!-- Header Info Begin -->
    <div class="header-info">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-4">
                    <div class="header-item">
                        <img src="<?php echo e(asset('ecomerce/img/icons/delivery.png')); ?>" alt="">
                        <p>Free shipping on orders over $30 in USA</p>
                    </div>
                </div>
                <div class="col-md-4 text-left text-lg-center">
                    <div class="header-item">
                        <img src="<?php echo e(asset('ecomerce/img/icons/voucher.png')); ?>" alt="">
                        <p>20% Student Discount</p>
                    </div>
                </div>
                <div class="col-md-4 text-left text-xl-right">
                    <div class="header-item">
                    <img src="<?php echo e(asset('ecomerce/img/icons/sales.png')); ?>" alt="">
                    <p>30% off on dresses. Use code: 30OFF</p>
                </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Header Info End -->
    <!-- Header End -->

    <!-- Hero Slider Mulai -->
    <section class="hero-slider">
        <div class="hero-items owl-carousel">
            <div class="single-slider-item set-bg" data-setbg="<?php echo e(asset('ecomerce/img/slider-1.jpg')); ?>">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1>2019</h1>
                            <h2>Koleksi Kaos Terbaru</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="single-slider-item set-bg" data-setbg="<?php echo e(asset('ecomerce/img/slider-2.jpg')); ?>">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1>2019</h1>
                            <h2>T-Shirt Kasual & Keren</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="single-slider-item set-bg" data-setbg="<?php echo e(asset('ecomerce/img/slider-3.jpg')); ?>">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1>2019</h1>
                            <h2>Tren Kaos Kekinian</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Slider Selesai -->

    <!-- Features Section Begin -->
    <section class="features-section spad">
        <div class="features-ads">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="single-features-ads first">
                            <img src="<?php echo e(asset('ecomerce/img/icons/f-delivery.png')); ?>" alt="">
                            <h4>Pengiriman Gratis</h4>
                            <p>Kami memberikan pengiriman gratis untuk setiap pembelian Anda. Nikmati kemudahan berbelanja tanpa biaya tambahan, langsung ke pintu rumah Anda.</p>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="single-features-ads second">
                            <img src="<?php echo e(asset('ecomerce/img/icons/coin.png')); ?>" alt="">
                            <h4>Jaminan Uang Kembali 100%</h4>
                            <p>Jika Anda tidak puas dengan produk kami, kami menawarkan jaminan uang kembali 100%. Belanja dengan rasa aman tanpa khawatir.</p>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="single-features-ads">
                            <img src="<?php echo e(asset('ecomerce/img/icons/chat.png')); ?>" alt="">
                            <h4>Support Online 24/7</h4>
                            <p>Tim customer service kami siap membantu kapan saja, 24 jam sehari, 7 hari seminggu. Kami selalu ada untuk menjawab pertanyaan Anda dan memberikan solusi terbaik.</p>
                        </div>
                    </div>
                </div>                
            </div>
        </div>
        <!-- Fitur Kotak -->
        <div class="features-box">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="single-box-item first-box">
                                    <img src="<?php echo e(asset('ecomerce/img/shirt.jpg')); ?>" alt="">
                                    <div class="box-text">
                                        <h2 style="color: rgb(255, 255, 255);">Atasan</h2>
                                        <span class="trend-alert" style="color: rgb(255, 255, 255);">Tren Terbaru</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="single-box-item second-box">
                                    <img src="<?php echo e(asset('ecomerce/img/tshirt2.jpg')); ?>" alt="">
                                    <div class="box-text">
                                        <span class="trend-year">Tren 2019</span>
                                        <h2 style="color: rgb(255, 255, 255);">T-Shirt</h2>
                                        <span class="trend-alert" style="color: rgb(255, 255, 255);">Elegan & Feminin</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="single-box-item large-box">
                            <img src="<?php echo e(asset('ecomerce/img/atasan.jpg')); ?>" alt="">
                            <div class="box-text">
                                <span class="trend-year">Pesta 2019</span>
                                <h2>Koleksi Pakaian</h2>
                                <div class="trend-alert">Tren Terbaru</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Features Section End -->

    <!-- Produk Terbaru Mulai -->
    <section class="latest-products spad">
        <div class="container">
            <div class="product-filter">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="section-title">
                            <h2>Kaos Terbaru</h2>
                        </div>
                        <ul class="product-controls">
                            <li data-filter="*">Semua</li>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li data-filter=".<?php echo e(strtolower($category->category_name)); ?>"><?php echo e($category->category_name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row" id="product-list">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-sm-6 mix all <?php echo e(strtolower($product->category->category_name ?? 'lainnya')); ?>">
                        <div class="single-product-item">
                            <figure>
                                <!-- Tautkan gambar ke halaman detail produk -->
                                <a href="<?php echo e(route('product.detail', ['id' => $product->product_id])); ?>">
                                    <img src="<?php echo e(asset('img/' . $product->image_url)); ?>" alt="<?php echo e($product->product_name); ?>">
                                </a>
                                <?php if($product->is_new): ?>
                                    <div class="p-status">Baru</div>
                                <?php elseif($product->is_popular): ?>
                                    <div class="p-status popular">Populer</div>
                                <?php elseif($product->is_on_sale): ?>
                                    <div class="p-status sale">Diskon</div>
                                <?php endif; ?>
                            </figure>
                            <div class="product-text">
                                <h6><?php echo e($product->product_name); ?></h6>
                                <p>Rp<?php echo e(number_format($product->price, 0, ',', '.')); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <!-- Latest Product End -->

    <!-- Lookbook Section Begin -->
    <section class="lookbok-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-4 offset-lg-1">
                    <div class="lookbok-left">
                        <div class="section-title">
                            <h2>2024 <br />#Lookbook</h2>
                        </div>
                        <p>Temukan gaya terkini yang penuh dengan inspirasi dan kenyamanan. Dari desain yang modern hingga sentuhan klasik, koleksi ini dirancang untuk menambah pesona setiap penampilan Anda. Bergaya tak hanya soal pakaian, tetapi juga cara Anda mengekspresikan diri. Jangan lewatkan momen untuk menampilkan gaya unik Anda dengan sentuhan yang tak terlupakan.</p>
                    </div>
                </div>
                <div class="col-lg-5 offset-lg-1">
                    <div class="lookbok-pic">
                        <img src="<?php echo e(asset('ecomerce/img/shirt.jpg')); ?>" alt="">
                        <div class="pic-text">fashion</div>
                    </div>
                </div>
            </div>
        </div>
    </section><br><br>
    <!-- Lookbook Section End -->

    <!-- Footer Section Begin -->
    <footer class="footer-section spad">
        <div class="container">
            <div class="footer-widget">
                <div class="row">
                    <div class="col-lg-12 col-sm-12">
                        <div class="single-footer-widget">
                            <h4>Cerita tentang T-Shirt</h4>
                            <p>T-Shirt bukan hanya sebuah pakaian, tetapi juga simbol dari gaya hidup, ekspresi diri, dan kenyamanan. Sejarah T-Shirt bermula dari pakaian dalam militer di awal abad ke-20, yang kemudian berevolusi menjadi salah satu pakaian paling populer di seluruh dunia. Kami terinspirasi untuk menghadirkan desain yang tidak hanya menarik, tetapi juga memiliki cerita dan makna. Setiap T-Shirt yang kami ciptakan dirancang dengan perhatian penuh terhadap detail, mulai dari pemilihan bahan berkualitas tinggi hingga proses pembuatan yang ramah lingkungan.</p>
                            <p>Kami percaya bahwa setiap orang berhak untuk tampil gaya tanpa mengorbankan kenyamanan. Oleh karena itu, kami menggunakan bahan-bahan terbaik yang lembut di kulit, tahan lama, dan cocok untuk segala aktivitas. Melalui inovasi desain dan komitmen terhadap kualitas, kami terus berupaya menghadirkan produk yang mencerminkan kepribadian Anda sekaligus memberikan pengalaman terbaik dalam berpakaian.</p>
                        </div>                        
                    </div>
                </div>
            </div>
        </div>
        <div class="social-links-warp">
            <div class="container text-center">
                <div class="social-links">
                    <a href="#" class="instagram"><i class="fa fa-instagram"></i><span>Instagram</span></a>
                    <a href="#" class="facebook"><i class="fa fa-facebook"></i><span>Facebook</span></a>
                    <a href="#" class="twitter"><i class="fa fa-twitter"></i><span>Twitter</span></a>
                    <a href="#" class="youtube"><i class="fa fa-youtube"></i><span>YouTube</span></a>
                </div>
            </div>
            <div class="container text-center pt-3">
                <p>&copy;<script>document.write(new Date().getFullYear());</script> Hak Cipta Dilindungi | Dibuat dengan <i class="icon-heart" aria-hidden="true"></i> oleh <a href="https://colorlib.com" target="_blank">Colorlib</a></p>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->


    <!-- Js Plugins -->
    <script src="<?php echo e(asset('ecomerce/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/jquery.slicknav.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/mixitup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/main.js')); ?>"></script>
    <script>
        $(document).ready(function () {
        var mixer = mixitup('#product-list', {
            selectors: {
                target: '.mix'
            },
            animation: {
                duration: 300
            }
        });
    });
    </script>
</body>

</html><?php /**PATH C:\laragon\www\baju\resources\views/public/home.blade.php ENDPATH**/ ?>