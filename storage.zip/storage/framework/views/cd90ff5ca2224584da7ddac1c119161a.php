

<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3">Dashboard Admin</h1>
</div>

<!-- Summary Cards -->
<div class="row">
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-info">
            <div class="card-body d-flex align-items-center">
                <i class="fas fa-users fa-2x mr-3"></i>
                <div>
                    <h5 class="card-title">Admin</h5>
                    <p class="card-text display-4"><?php echo e($adminCount); ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-success">
            <div class="card-body d-flex align-items-center">
                <i class="fas fa-user-friends fa-2x mr-3"></i>
                <div>
                    <h5 class="card-title">Customer</h5>
                    <p class="card-text display-4"><?php echo e($customerCount); ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-warning">
            <div class="card-body d-flex align-items-center">
                <i class="fas fa-cogs fa-2x mr-3"></i>
                <div>
                    <h5 class="card-title">Produk</h5>
                    <p class="card-text display-4"><?php echo e($productCount); ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-danger">
            <div class="card-body d-flex align-items-center">
                <i class="fas fa-cart-arrow-down fa-2x mr-3"></i>
                <div>
                    <h5 class="card-title">Pesanan</h5>
                    <p class="card-text display-4"><?php echo e($orderCount); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Ringkasan Pesanan -->
<div class="card mt-4">
    <div class="card-header bg-secondary text-white">
        <h5 class="mb-0">Ringkasan Pesanan</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Status</th>
                            <th>Jumlah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $statuses = ['Menunggu', 'Dikonfirmasi', 'DP', 'Lunas', 'Batal'];
                        ?>
                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($status); ?></td>
                                <td><?php echo e($statusCounts[$status] ?? 0); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="col-md-6">
                <canvas id="orderStatusChart" class="chart-container"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Pesanan Terbaru -->
<div class="card mt-4">
    <div class="card-header bg-dark text-white">
        <h5 class="mb-0">Pesanan Terbaru</h5>
    </div>
    <div class="card-body">
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>ID Pesanan</th>
                    <th>Nama Customer</th>
                    <th>Total Harga</th>
                    <th>Status</th>
                    <th>Tanggal</th>
                    <th>Struk</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order->order_id); ?></td>
                    <td><?php echo e($order->customer->full_name); ?></td>
                    <td>Rp <?php echo e(number_format($order->total_price, 0, ',', '.')); ?></td>
                    <td><?php echo e($order->status); ?></td>
                    <td><?php echo e($order->created_at->format('d-m-Y H:i')); ?></td>
                    <td>
                        <a href="<?php echo e(route('cetak-struk', $order->order_id)); ?>" class="btn btn-primary btn-sm" target="_blank">Cetak Struk</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Ringkasan Pesan Kontak -->
<div class="card mt-4">
    <div class="card-header bg-primary text-white">
        <h5 class="mb-0">Ringkasan Pesan Kontak</h5>
    </div>
    <div class="card-body">
        <table class="table table-striped table-bordered">
            <thead>
                <tr><th>Deskripsi</th><th>Jumlah</th></tr>
            </thead>
            <tbody>
                <tr><td>Total Pesan Kontak</td><td><?php echo e($messagesCount); ?></td></tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    var ctx = document.getElementById('orderStatusChart').getContext('2d');
    var orderStatusChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Menunggu', 'Dikonfirmasi', 'DP', 'Lunas', 'Batal'],
            datasets: [{
                data: [
                    <?php echo e($statusCounts['Menunggu'] ?? 0); ?>,
                    <?php echo e($statusCounts['Dikonfirmasi'] ?? 0); ?>,
                    <?php echo e($statusCounts['DP'] ?? 0); ?>,
                    <?php echo e($statusCounts['Lunas'] ?? 0); ?>,
                    <?php echo e($statusCounts['Batal'] ?? 0); ?>

                ],
                backgroundColor: ['#ffcc00', '#007bff', '#00bcd4', '#4caf50', '#f44336'],
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'top' },
                tooltip: {
                    callbacks: {
                        label: function(tooltipItem) {
                            return tooltipItem.raw + ' Pesanan';
                        }
                    }
                }
            },
            aspectRatio: 1.5
        }
    });
</script>

<style>
    .chart-container {
        max-width: 400px;
        height: 250px;
        margin: 0 auto;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\percobaan5\resources\views/dashboard/index.blade.php ENDPATH**/ ?>