<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Yoga Studio Template">
    <meta name="keywords" content="Yoga, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Violet | Template</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900&display=swap"
        rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/bootstrap.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/font-awesome.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/nice-select.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/owl.carousel.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/magnific-popup.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/slicknav.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('ecomerce/css/style.css')); ?>" type="text/css">
</head>

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>
    
    <!-- Search model -->
	<div class="search-model">
		<div class="h-100 d-flex align-items-center justify-content-center">
			<div class="search-close-switch">+</div>
			<form class="search-model-form">
				<input type="text" id="search-input" placeholder="Search here.....">
			</form>
		</div>
	</div>
	<!-- Search model end -->
<!-- Header Section Begin -->
<header class="header-section">
        <div class="container-fluid">
            <div class="inner-header">
                <div class="logo">
                    <a href="<?php echo e(route('public.home')); ?>"><h4>ASSTORE</h4></a>
                </div>
                <div class="header-right">
                    <!-- Menampilkan icon profile untuk pengguna yang sudah login -->
                    <?php if(auth()->guard('customer')->check()): ?>
                        <a href="<?php echo e(route('public.cart')); ?>">
                            <img src="<?php echo e(asset('ecomerce/img/icons/bag.png')); ?>" alt="">
                            <span><?php echo e(session('cart') ? array_sum(array_column(session('cart'), 'quantity')) : 0); ?></span> <!-- Menampilkan jumlah barang di cart -->
                        </a>
                    <?php endif; ?>

                    <!-- Menampilkan keranjang belanja untuk pengguna yang sudah login -->
                    <?php if(auth()->guard()->guest()): ?>
                        <a href="<?php echo e(route('login')); ?>">
                            <img src="<?php echo e(asset('ecomerce/img/icons/user.png')); ?>" alt=""> <!-- Icon untuk login -->
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Menu Navigasi -->
                <nav class="main-menu mobile-menu" style="center">
                    <ul>
                        <li><a href="<?php echo e(route('public.home')); ?>">Home</a></li>
                        <li><a class="active" href="<?php echo e(route('public.shop')); ?>">Shop</a></li>
                        <li><a href="<?php echo e(route('public.contact')); ?>">Contact</a></li>
                        
                        <?php if(Auth::guard('customer')->check()): ?>
                            
                            <li><span>Profile</span>
                                <ul class="sub-menu">
                                    <li><a href="<?php echo e(route('customer.profile')); ?>"><?php echo e(Auth::guard('customer')->user()->username); ?></a></li>
                                    <li>
                                        <form action="<?php echo e(route('customer.logout')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="dropdown-item text-danger">Logout</button>
                                        </form>
                                    </li>
                                </ul>
                            </li>
                            <li><a href="<?php echo e(route('public.pesanan')); ?>">Pesanan</a></li>
                        <?php else: ?>
                            
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
    <!-- Header Info Begin -->
    <div class="header-info">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-4">
                    <div class="header-item">
                        <img src="<?php echo e(asset('ecomerce/img/icons/delivery.png')); ?>" alt="">
                        <p>Free shipping on orders over $30 in USA</p>
                    </div>
                </div>
                <div class="col-md-4 text-left text-lg-center">
                    <div class="header-item">
                        <img src="<?php echo e(asset('ecomerce/img/icons/voucher.png')); ?>" alt="">
                        <p>20% Student Discount</p>
                    </div>
                </div>
                <div class="col-md-4 text-left text-xl-right">
                    <div class="header-item">
                    <img src="<?php echo e(asset('ecomerce/img/icons/sales.png')); ?>" alt="">
                    <p>30% off on dresses. Use code: 30OFF</p>
                </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Header Info End -->
    <!-- Produk Terbaru Mulai -->
    <section class="latest-products spad">
        <div class="container">
            <div class="product-filter">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="section-title">
                            <h2>Produk Terbaik</h2>
                        </div>
                        <ul class="product-controls">
                            <li data-filter="*">Semua</li>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li data-filter=".<?php echo e(strtolower($category->category_name)); ?>"><?php echo e($category->category_name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row" id="product-list">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-sm-6 mix all <?php echo e(strtolower($product->category->category_name ?? 'lainnya')); ?>">
                        <div class="single-product-item">
                            <figure>
                                <!-- Tautkan gambar ke halaman detail produk -->
                                <a href="<?php echo e(route('product.detail', ['id' => $product->product_id])); ?>">
                                    <img src="<?php echo e(asset('img/' . $product->image_url)); ?>" alt="<?php echo e($product->product_name); ?>">
                                </a>
                                <?php if($product->status === 'new'): ?>
                                    <div class="p-status">Baru</div>
                                <?php elseif($product->status === 'sale'): ?>
                                    <div class="p-status sale">Diskon</div>
                                <?php elseif($product->status === 'popular'): ?>
                                    <div class="p-status popular">Populer</div>
                                <?php endif; ?>
                            </figure>
                            <div class="product-text">
                                <h6><?php echo e($product->product_name); ?></h6>
                                <p>Rp<?php echo e(number_format($product->price, 0, ',', '.')); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- Produk Terbaru End -->


    <!-- Footer Section Begin -->
    <footer class="footer-section spad">
        <div class="container">
            <div class="footer-widget">
                <div class="row">
                    <div class="col-lg-12 col-sm-12">
                        <div class="single-footer-widget">
                            <h4>Cerita tentang T-Shirt</h4>
                            <p>T-Shirt bukan hanya sebuah pakaian, tetapi juga simbol dari gaya hidup, ekspresi diri, dan kenyamanan. Sejarah T-Shirt bermula dari pakaian dalam militer di awal abad ke-20, yang kemudian berevolusi menjadi salah satu pakaian paling populer di seluruh dunia. Kami terinspirasi untuk menghadirkan desain yang tidak hanya menarik, tetapi juga memiliki cerita dan makna. Setiap T-Shirt yang kami ciptakan dirancang dengan perhatian penuh terhadap detail, mulai dari pemilihan bahan berkualitas tinggi hingga proses pembuatan yang ramah lingkungan.</p>
                            <p>Kami percaya bahwa setiap orang berhak untuk tampil gaya tanpa mengorbankan kenyamanan. Oleh karena itu, kami menggunakan bahan-bahan terbaik yang lembut di kulit, tahan lama, dan cocok untuk segala aktivitas. Melalui inovasi desain dan komitmen terhadap kualitas, kami terus berupaya menghadirkan produk yang mencerminkan kepribadian Anda sekaligus memberikan pengalaman terbaik dalam berpakaian.</p>
                        </div>                        
                    </div>
                </div>
            </div>
        </div>
        <div class="social-links-warp">
            <div class="container text-center">
                <div class="social-links">
                    <a href="#" class="instagram"><i class="fa fa-instagram"></i><span>Instagram</span></a>
                    <a href="#" class="facebook"><i class="fa fa-facebook"></i><span>Facebook</span></a>
                    <a href="#" class="twitter"><i class="fa fa-twitter"></i><span>Twitter</span></a>
                    <a href="#" class="youtube"><i class="fa fa-youtube"></i><span>YouTube</span></a>
                </div>
            </div>
            <div class="container text-center pt-3">
                <p>&copy;<script>document.write(new Date().getFullYear());</script> Hak Cipta Dilindungi | Dibuat dengan <i class="icon-heart" aria-hidden="true"></i> oleh <a href="https://colorlib.com" target="_blank">Colorlib</a></p>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->

    <script src="<?php echo e(asset('ecomerce/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/jquery.slicknav.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/mixitup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ecomerce/js/main.js')); ?>"></script>
</body>

</html><?php /**PATH C:\laragon\www\baju\resources\views/public/shop.blade.php ENDPATH**/ ?>