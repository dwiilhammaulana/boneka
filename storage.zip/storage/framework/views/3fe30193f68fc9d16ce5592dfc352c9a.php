<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pembayaran Customer</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            background: url('https://source.unsplash.com/1600x900/?car,showroom') no-repeat center center fixed;
            background-size: cover;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .card {
            border-radius: 1rem;
            background: rgba(255, 255, 255, 0.25);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.18);
        }

        .badge-custom {
            font-size: 0.9rem;
            padding: 0.5em 0.75em;
        }

        .form-control,
        .btn {
            backdrop-filter: blur(2px);
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="mb-4 text-center fw-bold text-white text-shadow">Form Pembayaran Customer</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success" id="success-alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('info')): ?>
        <div class="alert alert-info" id="info-alert">
            <?php echo e(session('info')); ?>

        </div>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card p-4">
                <form id="formPembayaran" action="<?php echo e(route('public.PublicPembayaran.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <?php if(!empty($selectedOrderId)): ?>
                        <?php
                            $order = $orders->where('order_id', $selectedOrderId)->first();
                        ?>

                        <?php if($order): ?>
                            <div class="mb-4">
                                <h5 class="mb-3">Detail Pesanan</h5>
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="fw-semibold">No Pesanan:</span>
                                    <span class="badge bg-primary badge-custom">ID: <?php echo e($order->order_id); ?></span>
                                </div>
                                <input type="hidden" name="order_id" value="<?php echo e($order->order_id); ?>">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Total Bayar</label>
                                <input type="text" class="form-control bg-light" value="Rp <?php echo e(number_format($order->total_price, 0, ',', '.')); ?>" readonly>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Sisa Tagihan</label>
                                <input type="text" class="form-control bg-light" value="Rp <?php echo e(number_format($order->sisa_tagihan, 0, ',', '.')); ?>" readonly>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-warning">Pesanan tidak ditemukan.</div>
                        <?php endif; ?>

                        <div class="mb-3">
                            <label class="form-label">Jenis Pembayaran</label>
                            <input type="text" class="form-control bg-light" value="<?php echo e(ucfirst($jenisPembayaran)); ?>" readonly>
                            <input type="hidden" name="jenis_pembayaran" value="<?php echo e($jenisPembayaran); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="tanggal_pembayaran" class="form-label">Tanggal Pembayaran</label>
                            <input type="date" name="tanggal_pembayaran" id="tanggal_pembayaran"
                                   class="form-control <?php $__errorArgs = ['tanggal_pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   value="<?php echo e(old('tanggal_pembayaran', date('Y-m-d'))); ?>">
                            <?php $__errorArgs = ['tanggal_pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label for="metode" class="form-label">Metode Pembayaran</label>
                            <select name="metode" id="metode" class="form-select <?php $__errorArgs = ['metode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" onchange="toggleBuktiBayar()">
                                <option value="" disabled selected>Pilih Metode</option>
                                <option value="tunai" <?php echo e(old('metode') == 'tunai' ? 'selected' : ''); ?>>Tunai</option>
                                <option value="transfer" <?php echo e(old('metode') == 'transfer' ? 'selected' : ''); ?>>Transfer</option>
                            </select>
                            <?php $__errorArgs = ['metode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3" id="bukti-bayar-group" style="display: none;">
                            <label for="bukti_bayar" class="form-label">Upload Bukti Pembayaran</label>
                            <input type="file" name="bukti_bayar" id="bukti_bayar" class="form-control <?php $__errorArgs = ['bukti_bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept=".jpg,.jpeg,.png,.pdf">
                            <?php $__errorArgs = ['bukti_bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-success">Bayar Sekarang</button>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-warning">Silakan pilih pesanan terlebih dahulu.</div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function toggleBuktiBayar() {
        const metode = document.getElementById('metode').value;
        const buktiGroup = document.getElementById('bukti-bayar-group');
        const buktiInput = document.getElementById('bukti_bayar');

        if (metode === 'transfer') {
            buktiGroup.style.display = 'block';
        } else {
            buktiGroup.style.display = 'none';
            buktiInput.value = '';
        }
    }

    // Trigger on page load if old value exists
    window.onload = function () {
        toggleBuktiBayar();
    };

    // SweetAlert form validation
    document.getElementById('formPembayaran').addEventListener('submit', function (e) {
        const tanggal = document.getElementById('tanggal_pembayaran').value;
        const metode = document.getElementById('metode').value;
        const bukti = document.getElementById('bukti_bayar').value;

        if (!tanggal || !metode || (metode === 'transfer' && !bukti)) {
            e.preventDefault();
            Swal.fire({
                icon: 'warning',
                title: 'Form belum lengkap!',
                text: 'Harap lengkapi semua data yang dibutuhkan.',
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'OK'
            });
        }
    });

    // Hide alert after 3 seconds
    setTimeout(() => {
        const alerts = ['success-alert', 'info-alert'];
        alerts.forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                el.style.transition = 'opacity 0.5s ease-out';
                el.style.opacity = '0';
                setTimeout(() => el.remove(), 500);
            }
        });
    }, 3000);
</script>

</body>
</html>
<?php /**PATH C:\laragon\www\percobaan5\resources\views/public/pembayaran/create.blade.php ENDPATH**/ ?>