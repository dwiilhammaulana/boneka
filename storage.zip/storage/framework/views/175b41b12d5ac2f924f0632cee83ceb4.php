

<?php $__env->startSection('title', 'Pembayaran Saya'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $order = $orders->firstWhere('order_id', $selectedOrderId);
    ?>

    <?php if($order): ?>
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3">Pembayaran</h1>
        </div>

        <form action="<?php echo e(route('pembayaran.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <input type="hidden" name="order_id" value="<?php echo e($order->order_id); ?>">

            <div class="mb-3">
                <label class="form-label">No Order</label>
                <input type="text" class="form-control" value="<?php echo e($order->order_id); ?>" readonly>
            </div>

            <div class="mb-3">
                <label for="tanggal_pembayaran" class="form-label">Tanggal Pembayaran <span class="text-danger">*</span></label>
                <input type="date" class="form-control <?php $__errorArgs = ['tanggal_pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                       name="tanggal_pembayaran" id="tanggal_pembayaran" 
                       value="<?php echo e(old('tanggal_pembayaran', date('Y-m-d'))); ?>" required>
                <?php $__errorArgs = ['tanggal_pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <input type="hidden" name="jenis_pembayaran" value="<?php echo e($jenisPembayaran); ?>">

            <div class="mb-3">
                <label class="form-label">Jenis Pembayaran</label>
                <input type="text" class="form-control" value="<?php echo e(ucfirst($jenisPembayaran)); ?>" readonly>
            </div>

            <?php if(isset($order->total_harga)): ?>
                <div class="mb-3">
                    <label class="form-label">Jumlah Bayar</label>
                    <input type="text" class="form-control" value="Rp <?php echo e(number_format($order->total_harga, 0, ',', '.')); ?>" readonly>
                </div>
            <?php endif; ?>

            <button type="submit" class="btn btn-primary">Kirim Pembayaran</button>
            <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-secondary">Batal</a>
        </form>
    <?php else: ?>
        <div class="alert alert-danger">
            Data order tidak ditemukan.
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\percobaan5\resources\views/public/bayar.blade.php ENDPATH**/ ?>