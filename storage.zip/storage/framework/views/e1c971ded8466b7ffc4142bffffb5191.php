

<?php $__env->startSection('title', 'Daftar Kategori'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3">Daftar Kategori</h1>
        <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary">Tambah Kategori</a>
    </div>

    <!-- Table -->
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Daftar Kategori</h5>
        </div>
        <div class="card-body">
            <table class="table table-striped table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Nama Kategori</th>
                        <th>Deskripsi</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  <!-- Looping melalui masing-masing kategori -->
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($category->category_name); ?></td>
                        <td><?php echo e($category->description); ?></td>
                        <td>
                            <a href="<?php echo e(route('categories.show', $category->category_id)); ?>" class="btn btn-info btn-sm">Detail</a>
                            <a href="<?php echo e(route('categories.edit', $category->category_id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                            <form action="<?php echo e(route('categories.destroy', $category->category_id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\percobaan5\resources\views/categories/index.blade.php ENDPATH**/ ?>