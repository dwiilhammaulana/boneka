

<?php $__env->startSection('title', 'Laporan Penjualan'); ?>

<?php $__env->startSection('content'); ?>

<style>
    @media print {
        body * {
            visibility: hidden;
        }

        .print-area, .print-area * {
            visibility: visible;
        }

        .print-area {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
        }

        .no-print {
            display: none !important;
        }
    }
</style>

<div class="container">

    
    <form method="GET" class="row g-3 mb-4 no-print">
        <div class="col-md-3">
            <label>Tanggal</label>
            <input type="date" name="tanggal" value="<?php echo e(request('tanggal')); ?>" class="form-control">
        </div>
        <div class="col-md-3">
            <label>Bulan</label>
            <input type="number" name="bulan" value="<?php echo e(request('bulan')); ?>" class="form-control" placeholder="1-12">
        </div>
        <div class="col-md-3">
            <label>Tahun</label>
            <input type="number" name="tahun" value="<?php echo e(request('tahun')); ?>" class="form-control" placeholder="2025">
        </div>
        <div class="col-md-3 d-flex align-items-end">
            <button type="submit" class="btn btn-primary w-100">Filter</button>
        </div>
    </form>

    <?php if($dataPenjualan->isEmpty()): ?>
        <div class="alert alert-info no-print">Belum ada data penjualan lunas.</div>
    <?php else: ?>
        <div class="print-area">
            
            <h3 class="text-center mb-3">Laporan Penjualan (Status: Lunas)</h3>

            
            <p><strong>Filter Tanggal:</strong> 
                <?php if(request('tanggal')): ?>
                    <?php echo e(\Carbon\Carbon::parse(request('tanggal'))->format('d M Y')); ?>

                <?php elseif(request('bulan') && request('tahun')): ?>
                    Bulan <?php echo e(request('bulan')); ?> Tahun <?php echo e(request('tahun')); ?>

                <?php elseif(request('tahun')): ?>
                    Tahun <?php echo e(request('tahun')); ?>

                <?php else: ?>
                    Semua Data
                <?php endif; ?>
            </p>

            
            <table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>Tanggal</th>
                        <th>ID Pesanan</th>
                        <th>Nama Pelanggan</th>
                        <th class="text-end">Harga</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $dataPenjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(\Carbon\Carbon::parse($row->order_date)->format('d M Y')); ?></td>
                            <td><?php echo e($row->order_id); ?></td>
                            <td><?php echo e($row->full_name); ?></td>
                            <td class="text-end">Rp <?php echo e(number_format($row->total_price, 0, ',', '.')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr class="table-success fw-bold">
                        <td colspan="3" class="text-end">Total Penjualan:</td>
                        <td class="text-end">Rp <?php echo e(number_format($totalPendapatan, 0, ',', '.')); ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    <?php endif; ?>

    
    <div class="text-end mt-4 no-print">
        <button type="button" onclick="window.print()" class="btn btn-success">Cetak Laporan</button>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\jual_beli_mobil\resources\views/laporan/penjualan.blade.php ENDPATH**/ ?>