

<?php $__env->startSection('title', 'Daftar Pesanan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3">Daftar Pesanan</h1>
        <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-primary">Tambah Pesanan</a>
    </div>

    
    <?php if(session('info')): ?>
        <div class="alert alert-success" id="info-alert">
            <?php echo e(session('info')); ?>

        </div>
    <?php endif; ?>

    <!-- Table -->
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Daftar Pesanan</h5>
        </div>
        <div class="card-body">
            <table class="table table-striped table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Nama Pelanggan</th>
                        <th>Tanggal Pesan</th>
                        <th>Total Harga</th>
                        <th>Sisa Angsuran</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; ?>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($order->status !== 'Menunggu'): ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($order->customer->username); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($order->order_date)->format('d/m/Y')); ?></td>
                                <td><?php echo e(number_format($order->total_price, 2)); ?></td>
                                <td><?php echo e(number_format($order->sisa_tagihan, 2)); ?></td>
                                <td><?php echo e(ucfirst($order->status)); ?></td>
                                <td>
                                    <a href="<?php echo e(route('orders.show', $order->order_id)); ?>" class="btn btn-info btn-sm">Detail</a>
                                    <a href="<?php echo e(route('cetak-struk', $order->order_id)); ?>" class="btn btn-primary btn-sm" target="_blank">Cetak Struk</a>    
                                    <a href="<?php echo e(route('orders.edit', $order->order_id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                    
                                        <?php if($order->sisa_tagihan > 0 && strtolower($order->status) !== 'lunas' && strtolower($order->status) !== 'batal'): ?>
                                            <a href="<?php echo e(route('pembayaran.create', ['order_id' => $order->order_id])); ?>" class="btn btn-success btn-sm">Pembayaran</a>
                                        <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <script>
        setTimeout(function () {
            let alert = document.getElementById('info-alert');
            if (alert) {
                alert.style.transition = 'opacity 0.5s ease-out';
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 500);
            }
        }, 3000);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\percobaan5\resources\views/orders/index.blade.php ENDPATH**/ ?>