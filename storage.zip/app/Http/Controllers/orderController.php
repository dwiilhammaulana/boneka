<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\orders;
use App\Models\orders_details;
use App\Models\customers;
use App\Models\products;
use Illuminate\Support\Facades\Auth;
use FPDF;
use Imagick;
require_once app_path('Libraries/FPDF/fpdf.php');

class orderController extends Controller
{
    public function index()
    {
        // Mengambil semua order beserta detailnya
        $orders = orders::with('orderDetails.product')->get();

        return view('orders.index', compact('orders'));
    }

    
    // Menampilkan form untuk membuat order bar

public function create()
{
    // Cek apakah customer sudah login dengan guard 'customer'
    if (!Auth::guard('customer')->check()) {
        // Jika belum login, redirect ke halaman login customer dengan pesan error
        return redirect()->route('login')->with('error', 'Silakan login terlebih dahulu.');
    }
    
    // Jika sudah login (else tidak perlu karena sudah ada return di atas)
    $cart = session('cart', []); // Ambil data keranjang dari session
    $customers = customers::all(); // Ambil data pelanggan
    $products = products::all(); // Ambil data produk

    return view('public.checkout', compact('cart', 'customers', 'products'));
}

public function cancel(orders $order)
{
    $order->status = 'Batal';
    $order->save();

    return response()->json(['message' => 'Status pesanan sudah diubah menjadi Batal']);
}

public function updateLogistik(Request $request, $id)
{
    $order = orders::findOrFail($id);

    $validated = $request->validate([
        'logistik' => 'required|in:request_pickup,pickup',
    ]);

    $order->logistik = $validated['logistik'];
    $order->save();

    return response()->json(['success' => true, 'message' => 'Status logistik berhasil diperbarui.']);
}



    // Menyimpan order baru beserta detailnya

   public function store(Request $request)
{
    // Validasi input
    $request->validate([
        'customer_id' => 'required|exists:customers,customer_id',
        'order_date' => 'required|date',
        'total_price' => 'required|numeric',
        'bukti_pesanan' => 'required',
        'status' => 'required|string',
        'ktp' => 'required|image|mimes:jpg,jpeg,png|max:2048',
        'order_details' => 'required|array',
        'order_details.*.product_id' => 'required|exists:products,product_id',
        'order_details.*.quantity' => 'required|integer',
        'order_details.*.price' => 'required|numeric',
    ]);

    // Hapus titik dari nilai bukti_pesanan, lalu cast ke integer
    $bukti = (int) str_replace('.', '', $request->bukti_pesanan);

    // Simpan file gambar KTP
    $ktpPath = $this->saveImage($request, 'ktp', 'uploads/ktp');

    // Simpan data order
    $order = Orders::create([
        'customer_id'   => $request->customer_id,
        'order_date'    => $request->order_date,
        'total_price'   => $request->total_price,
        'bukti_pesanan' => $bukti,
        'ktp'           => $ktpPath,
        'status'        => $request->status,
        'sisa_tagihan'  => $request->total_price,
    ]);

    // Simpan detail pesanan
    foreach ($request->order_details as $detail) {
        Orders_Details::create([
            'order_id'   => $order->order_id,
            'product_id' => $detail['product_id'],
            'quantity'   => $detail['quantity'],
            'price'      => $detail['price'],
        ]);
    }

    // Hapus isi keranjang dari session
    session()->forget('cart');

    // Redirect dengan pesan sukses
    return redirect()->route('public.home')->with('success', 'Order berhasil dibuat dan keranjang Anda telah dikosongkan!');
}




    public function history()
{
    // Cek apakah user sudah login sebagai customer
    if (!Auth::guard('customer')->check()) {
        return redirect()->route('login')->with('error', 'Silakan login terlebih dahulu');
    }

    // Mendapatkan customer_id dari Auth guard
    $customerId = Auth::guard('customer')->user()->customer_id;

    // Mengambil data order dan details berdasarkan customer_id
    $orders = orders::with('orderDetails.product')
        ->where('customer_id', $customerId)
        ->orderBy('order_date', 'desc')
        ->get();

    // Kirim data ke view
    return view('public.pesanan', compact('orders'));
}


 public function cetakStruk($orderId)
{
    $order = orders::with(['orderDetails.product', 'customer'])->findOrFail($orderId);

    $pdf = new FPDF();
    $pdf->AddPage();

    $pdf->SetMargins(10, 10, 10);
    $pdf->SetAutoPageBreak(true, 20);
    $pdf->SetFont('Arial', '', 12);

    // TIMESTAMP DI POJOK KANAN ATAS
    date_default_timezone_set('Asia/Jakarta');
    $pdf->SetFont('Arial', 'I', 9);
    $pdf->Cell(0, 5, 'Dicetak: ' . date('d-m-Y H:i:s'), 0, 0, 'R');
    $pdf->Ln(10);

    // HEADER
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 7, 'BJM - Berkah Jaya Motor Mobilindo', 0, 1);
    $pdf->SetFont('Arial', '', 10);
    $pdf->MultiCell(0, 6, "Arengka 1 No 36 D-E, Jl. Soekarno - Hatta,\nSidomulyo Tim., Kecamatan Marpoyan, Kota Pekanbaru, Riau 28125\nNo HP: 0852-6552-7838\nEmail: info@bjm.com");
    $pdf->Ln(5);

    // CUSTOMER
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 7, 'Kepada:', 0, 1);
    $pdf->SetFont('Arial', '', 11);
    $pdf->Cell(0, 6, $order->customer->username ?? $order->customer->full_name ?? '-', 0, 1);
    $pdf->Cell(0, 6, 'No HP: ' . ($order->customer->phone_number ?? '-'), 0, 1);
    $pdf->Cell(0, 6, 'Email: ' . ($order->customer->email ?? '-'), 0, 1);
    $pdf->Ln(8);

    // ORDER INFO TABLE
    $headers = ['Order ID', 'Tanggal Pembelian', 'STNK', 'BPKB', 'Status'];
    $pdf->SetFillColor(200, 50, 50);
    $pdf->SetTextColor(255, 255, 255);
    $pdf->SetFont('Arial', 'B', 11);

    $colWidth = 190 / count($headers);
    foreach ($headers as $header) {
        $pdf->Cell($colWidth, 8, $header, 1, 0, 'C', true);
    }
    $pdf->Ln();

    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetFont('Arial', '', 11);

    $bulanIndo = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
    ];
    $tanggal = date('j', strtotime($order->order_date));
    $bulan = $bulanIndo[(int)date('n', strtotime($order->order_date))];
    $tahun = date('Y', strtotime($order->order_date));
    $tanggalBeli = "$tanggal $bulan $tahun";

    $infoData = [
        $order->order_id,
        $tanggalBeli,
        $order->stnk ?? '-',
        $order->bpkb ?? '-',
        $order->status ?? '-'
    ];
    foreach ($infoData as $info) {
        $pdf->Cell($colWidth, 8, $info, 1, 0, 'C');
    }
    $pdf->Ln(10);

    // TABEL LOGISTIK jika status = lunas
    if (strtolower($order->status) === 'lunas') {
        $pdf->SetFont('Arial', 'B', 11);
        $pdf->SetFillColor(220, 53, 69);
        $pdf->SetTextColor(255, 255, 255);
        $pdf->Cell(190, 8, 'Logistik', 1, 1, 'C', true);

        $pdf->SetFont('Arial', '', 11);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->Cell(190, 8, $order->logistik ?? '-', 1, 1, 'C');
        $pdf->Ln(10);
    }

    // DETAIL PRODUK
    $columns = ['No', 'Nama Produk', 'Kilometer', 'Warna Produk', 'Jumlah', 'Harga'];
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->SetFillColor(255, 102, 102);

    $pdf->SetFont('Arial', '', 10);
    $colWidths = [];
    foreach ($columns as $index => $col) {
        $maxWidth = $pdf->GetStringWidth($col) + 6;
        foreach ($order->orderDetails as $i => $detail) {
            $product = $detail->product;
            switch ($col) {
                case 'No': $value = (string)($i + 1); break;
                case 'Nama Produk': $value = $product->product_name ?? '-'; break;
                case 'Kilometer': $value = ($product->kilometer ?? '-') . ' Km'; break;
                case 'Warna Produk': $value = $product->warna ?? '-'; break;
                case 'Jumlah': $value = (string)$detail->quantity; break;
                case 'Harga': $value = 'Rp ' . number_format($detail->price, 0, ',', '.'); break;
                default: $value = '-';
            }
            $cellWidth = $pdf->GetStringWidth($value) + 6;
            if ($cellWidth > $maxWidth) {
                $maxWidth = $cellWidth;
            }
        }
        $colWidths[$index] = $maxWidth;
    }

    $fixedTableWidth = 190;
    $totalColWidth = array_sum($colWidths);
    foreach ($colWidths as $i => $w) {
        $colWidths[$i] = $w * ($fixedTableWidth / $totalColWidth);
    }

    $pdf->SetFont('Arial', 'B', 10);
    foreach ($columns as $i => $col) {
        $pdf->Cell($colWidths[$i], 10, $col, 1, 0, 'C', true);
    }
    $pdf->Ln();

    $pdf->SetFont('Arial', '', 10);
    $no = 1;
    $totalProduk = 0;
    foreach ($order->orderDetails as $detail) {
        $product = $detail->product;
        $subtotal = $detail->price * $detail->quantity;
        $totalProduk += $subtotal;

        $values = [
            $no++,
            $product->product_name ?? '-',
            ($product->kilometer ?? '-') . ' Km',
            $product->warna ?? '-',
            $detail->quantity,
            'Rp ' . number_format($detail->price, 0, ',', '.'),
        ];

        foreach ($values as $i => $val) {
            $pdf->Cell($colWidths[$i], 10, $val, 1, 0, 'C');
        }
        $pdf->Ln();
    }

    $pdf->Ln(5);

    // TOTAL
    $buktiPesanan = 500000;
    $total = $totalProduk + $buktiPesanan;
    $sisaTagihan = $total;

    $labelWidth = array_sum($colWidths) - end($colWidths);
    $valueWidth = end($colWidths);

    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell($labelWidth, 10, 'Jumlah Total Produk', 1, 0, 'L');
    $pdf->Cell($valueWidth, 10, 'Rp ' . number_format($totalProduk, 0, ',', '.'), 1, 1, 'C');

    $pdf->Cell($labelWidth, 10, 'Bukti Pesanan', 1, 0, 'L');
    $pdf->Cell($valueWidth, 10, 'Rp ' . number_format($buktiPesanan, 0, ',', '.'), 1, 1, 'C');

    $pdf->Cell($labelWidth, 10, 'TOTAL', 1, 0, 'L');
    $pdf->Cell($valueWidth, 10, 'Rp ' . number_format($total, 0, ',', '.'), 1, 1, 'C');

    $pdf->Cell($labelWidth, 10, 'Sisa Tagihan', 1, 0, 'L');
    $pdf->Cell($valueWidth, 10, 'Rp ' . number_format($sisaTagihan, 0, ',', '.'), 1, 1, 'C');

    $pdf->Ln(10);

    if (strtolower($order->status) === 'dikonfirmasi') {
        $tglTempo = date('Y-m-d', strtotime($order->order_date . ' +7 days'));
        $tgl = date('j', strtotime($tglTempo));
        $bln = $bulanIndo[(int)date('n', strtotime($tglTempo))];
        $thn = date('Y', strtotime($tglTempo));
        $tanggalTempo = "$tgl $bln $thn";

        $pdf->SetFont('Arial', 'I', 10);
        $pdf->Cell(0, 6, 'Bayar sebelum tanggal: ' . $tanggalTempo, 0, 1, 'L');
    }

    // KTP
    $pdf->Ln(10);
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'KTP Terlampir:', 0, 1);

    $ktpPath = public_path('uploads/ktp/' . $order->ktp);

    if ($order->ktp && file_exists($ktpPath)) {
        $yBefore = $pdf->GetY();
        $pdf->Image($ktpPath, 10, $yBefore, 100);
        $pdf->SetY($yBefore + 60);
    } else {
        $pdf->SetFont('Arial', 'I', 10);
        $pdf->Cell(0, 6, 'Tidak ada file KTP yang terlampir.', 0, 1, 'L');
    }

    $pdf->Ln(10);
    $pdf->SetFont('Arial', 'I', 10);
    $pdf->Cell(0, 6, 'Harap simpan struk ini sebagai bukti pesanan.', 0, 1, 'L');

    $pdf->Output();
    exit;
}


    // Menampilkan detail order tertentu
    public function show($id)
    {
        $order = orders::with('orderDetails.product')->findOrFail($id);

        return view('orders.show', compact('order'));
    }

    // Menampilkan form untuk mengedit order
    public function edit($id)
    {
        // Mengambil data order beserta detailnya
        $order = Orders::with('details')->findOrFail($id);

        // Mengambil data pelanggan dan produk untuk dropdown
        $customers = Customers::all();
        $products = Products::all();

        return view('orders.edit', compact('order', 'customers', 'products'));
    }

    // Menyimpan perubahan pada order
    public function update(Request $request, $id)
{
    $request->validate([
        'status' => 'required|string',
        'stnk' => 'nullable|string',
        'bpkb' => 'nullable|string',
        'logistik' => 'nullable|string',
        'sisa_tagihan' => 'required|numeric',
        'ktp_file' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
    ]);

    $order = orders::findOrFail($id);

    // Proses upload file KTP baru jika ada
    if ($request->hasFile('ktp_file')) {
        $file = $request->file('ktp_file');
        $filename = time() . '.' . $file->getClientOriginalExtension();
        $file->move(public_path('uploads/ktp'), $filename);

        // Hapus file KTP lama jika ada
        if ($order->ktp && file_exists(public_path('uploads/ktp/' . $order->ktp))) {
            unlink(public_path('uploads/ktp/' . $order->ktp));
        }

        $order->ktp = $filename;
    }

    // Update data yang boleh diubah
    $order->status = $request->status;
    $order->stnk = $request->stnk;
    $order->bpkb = $request->bpkb;
    $order->logistik = $request->logistik;
    $order->sisa_tagihan = $request->sisa_tagihan;
    $order->save();

    return redirect()->route('orders.index')->with('success', 'Order berhasil diperbarui!');
}


protected function saveImage(Request $request, $field, $folder = 'uploads/ktp')
{
    if ($request->hasFile($field)) {
        $file = $request->file($field);
        $filename = time() . '.' . $file->getClientOriginalExtension();
        $file->move(public_path($folder), $filename); // simpan ke public/uploads/ktp
        return $filename;
    }
    return null;
}



    public function checkout()
    {
        // Ambil data keranjang dari sesi
        $cart = session('cart', []);

        // Ambil data pelanggan (opsional jika diperlukan)
        $customers = customers::all();

        return view('public.checkout', compact('cart', 'customers'));
    }


}
