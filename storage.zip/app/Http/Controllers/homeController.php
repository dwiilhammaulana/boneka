<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Products; // Pastikan menggunakan penulisan PascalCase (singular)
use App\Models\Category;

class HomeController extends Controller // Disarankan PascalCase untuk nama class
{
    public function index()
    {
        // Ambil data kategori
        $categories = Category::all();

        // Ambil produk dengan filter: stok > 0 dan status 'Approved', diurutkan terbaru
        $products = Products::where('stock', '>', 0)
            ->where('status', 'Approved')
            ->orderBy('created_at', 'DESC')
            ->take(8)
            ->get();

        return view('public.home', compact('categories', 'products'));
    }
}