<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Invoice - BJM Mobilindo</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('ecomerce/css/bootstrap.min.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('ecomerce/css/font-awesome.min.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('ecomerce/css/nice-select.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('ecomerce/css/owl.carousel.min.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('ecomerce/css/magnific-popup.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('ecomerce/css/slicknav.min.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('ecomerce/css/style.css') }}" type="text/css">
<style>
body {
    background-color: #f8f9fa;
}
.navbar-brand span {
    font-weight: bold;
    color: #d90429;
}
.invoice-box {
    background: white;
    padding: 30px;
    margin-top: 30px;
    border-radius: 10px;
    box-shadow: 0 0 10px #ccc;
}
.highlight {
    background-color: #d90429;
    color: white;
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 20px;
}
.total-box {
    font-size: 1.3rem;
    font-weight: bold;
}
.table > :not(:first-child) {
    border-top: 2px solid #dee2e6;
}
</style>
</head>
<body>

<!-- NAVBAR -->


<!-- resources/views/partials/header.blade.php -->

<header class="header-section">
    <div class="container-fluid">
        <div class="inner-header">
            <div class="logo">
                <a href="{{ route('public.home') }}"><h4>ASSTORE</h4></a>
            </div>
            <div class="header-right">
                @auth('customer')
                    <a class="active" href="{{ route('public.cart') }}">
                        <img src="{{ asset('ecomerce/img/icons/bag.png') }}" alt="">
                        <span>{{ session('cart') ? array_sum(array_column(session('cart'), 'quantity')) : 0 }}</span>
                    </a>
                @endauth

                @guest
                    <a href="{{ route('login') }}">
                        <img src="{{ asset('ecomerce/img/icons/user.png') }}" alt="">
                    </a>
                @endguest
            </div>

            <nav class="main-menu mobile-menu">
                <ul>
                    <li><a href="{{ route('public.home') }}">Home</a></li>
                    <li><a href="{{ route('public.shop') }}">Shop</a></li>
                    <li><a href="{{ route('public.contact') }}">Contact</a></li>

                    @auth('customer')
                        <li><span>Profile</span>
                            <ul class="sub-menu">
                                <li><a href="{{ route('customer.profile') }}">{{ Auth::guard('customer')->user()->username }}</a></li>
                                <li>
                                    <form action="{{ route('customer.logout') }}" method="POST">
                                        @csrf
                                        <button type="submit" class="dropdown-item text-danger">Logout</button>
                                    </form>
                                </li>
                            </ul>
                        </li>
                        <li><a href="{{ route('public.pesanan') }}">Pesanan</a></li>
                    @else
                        <li><a href="{{ route('login') }}">Login</a></li>
                    @endauth
                </ul>
            </nav>
        </div>
    </div>
</header>

<div class="header-info">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4">
                <div class="header-item">
                    <img src="img/icons/delivery.png" alt="">
                    <p>Free shipping on orders over $30 in USA</p>
                </div>
            </div>
            <div class="col-md-4 text-left text-lg-center">
                <div class="header-item">
                    <img src="img/icons/voucher.png" alt="">
                    <p>20% Student Discount</p>
                </div>
            </div>
            <div class="col-md-4 text-left text-xl-right">
                <div class="header-item">
                    <img src="img/icons/sales.png" alt="">
                    <p>30% off on dresses. Use code: 30OFF</p>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- INVOICE CONTENT -->
<div class="container">
<div class="invoice-box">

<h2 class="text-center mb-4">Invoice</h2>

<div class="row">
    <div class="col-md-6">
        <strong>Dari</strong><br>
        <b>BJM - Berkah Jaya Motor Mobilindo</b><br>
        Arengka 1 No 36 D-E, Jl. Soekarno - Hatta,<br>
        Sidomulyo Tim., Kecamatan Marpoyan, Kota Pekanbaru, Riau 28125<br>
        <strong>No HP:</strong> 0852-6552-7838<br>
        <strong>Email:</strong> info@bjm.com
    </div>
    <div class="col-md-6 text-end">
        <h4>{{ \Carbon\Carbon::now()->locale('id')->isoFormat('D MMMM YYYY') }}</h4>
        <strong>Kepada</strong><br>
        {{ Auth::guard('customer')->user()->username }}<br>
        <strong>No HP:</strong> {{ Auth::guard('customer')->user()->phone_number }}<br>
        <strong>Email:</strong> {{ Auth::guard('customer')->user()->email }}<br>
    </div>
</div>

<div class="row highlight text-white mt-4">
    <div class="col">Invoice: <strong>#r4HyuBS9xV</strong></div>
    <div class="col">Order ID: <strong>p8pn8GsKDR</strong></div>
    @php
    use Carbon\Carbon;
@endphp

<div class="col">Tanggal Pembelian: <strong>{{ Carbon::now()->translatedFormat('d F Y') }}</strong></div>

    <div class="col">Account: <strong>{{ Auth::guard('customer')->user()->customer_id }}</strong></div>
</div>

<table class="table table-bordered mt-3">
    <thead class="table-light">
        <tr>
            <th>No</th>
            <th>Gambar</th>
            <th>Nama Produk</th>
            <th>Tipe Produk</th>
            <th>Warna Produk</th>
            <th>Jumlah Produk</th>
            <th>Harga</th>
        </tr>
    </thead>
    <tbody>
        @if(!empty($cart))
            @foreach($cart as $id => $item)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>
                        @if(!empty($item['image']))
                            <img src="{{ asset('img/' . $item['image']) }}" alt="{{ $item['name'] }}" style="width: 60px; height: auto;">
                        @else
                            <span>-</span>
                        @endif
                    </td>
                    <td>{{ $item['name'] }}</td>
                    <td>{{ $item['kilometer'] ?? '-' }}</td>
                    <td>{{ $item['warna'] }}</td>
                    <td>{{ $item['quantity'] }}</td>
                    <td>Rp{{ number_format($item['price'], 0, ',', '.') }}</td>
                </tr>
            @endforeach
        @else
            <tr>
                <td colspan="7" class="text-center">Keranjang Anda kosong.</td>
            </tr>
        @endif
    </tbody>
</table>

@php
    $bukti_pesanan = 500000;
    $totalProduk = 0;
    if(!empty($cart)) {
        foreach($cart as $item) {
            $totalProduk += $item['price'] * $item['quantity'];
        }
    }
    $total = $totalProduk + $bukti_pesanan;
@endphp

<div class="mt-4">
    @php
    $bayar_sebelum = \Carbon\Carbon::now()->addDays(7)->locale('id')->isoFormat('D MMMM YYYY');
@endphp

<p><strong>Bayar Sebelum Tanggal:</strong> <span class="text-danger">{{ $bayar_sebelum }}</span></p>

    <p><strong>Jumlah Total Produk:</strong> Rp {{ number_format($totalProduk, 0, ',', '.') }}</p>
    <p><strong>Bukti Pesanan:</strong> Rp {{ number_format($bukti_pesanan, 0, ',', '.') }}</p>
    <p class="total-box"><strong>Total:</strong> Rp {{ number_format($total, 0, ',', '.') }}</p>
</div>

<!-- FORM untuk submit data -->
<form action="{{ route('orders.store') }}" method="POST" enctype="multipart/form-data">
    @csrf

    <!-- Hidden Inputs -->
    <input type="hidden" name="customer_id" value="{{ Auth::guard('customer')->user()->customer_id }}">
    <input type="hidden" name="order_date" value="{{ date('Y-m-d') }}">
    <input type="hidden" name="total_price" value="{{ $total }}">
    <input type="hidden" name="bukti_pesanan" value="{{ $bukti_pesanan }}">
    <input type="hidden" name="status" value="Menunggu">

    <!-- Order Details -->
    @foreach ($cart as $id => $item)
        <input type="hidden" name="order_details[{{ $loop->index }}][product_id]" value="{{ $id }}">
        <input type="hidden" name="order_details[{{ $loop->index }}][quantity]" value="{{ $item['quantity'] }}">
        <input type="hidden" name="order_details[{{ $loop->index }}][price]" value="{{ $item['price'] }}">
    @endforeach

    <!-- Upload Foto KTP -->
    <div class="mb-3">
        <label for="ktp" class="form-label"><strong>Upload Foto KTP</strong></label>
        <input type="file" class="form-control" id="ktp" name="ktp" accept="image/*" required>
    </div>

    <!-- Tombol Submit -->
    <div class="mt-4 text-center">
        <button type="submit" class="btn btn-success btn-lg">buat pesanan</button>
    </div>
</form>

</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
